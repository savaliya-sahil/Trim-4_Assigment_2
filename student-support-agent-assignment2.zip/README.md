# 🎓 Intelligent Student Support Agent

**Agentic AI Engineering — Assignment 1 + Assignment 2**

A working AI agent (not just a chatbot UI) that answers student questions about **fees, scholarships, courses, support requests and handbook policies**. It decides whether to answer directly, call a tool, retrieve policy text, use remembered preferences, ask for missing details, or honestly say it does not know.

Assignment 2 extends the same project with **authentication, authorization, a human-approval workflow for sensitive actions, audit logging, and sensitive-data protection**. All students, fees, scholarships, tickets, and policies are **SYNTHETIC / FICTIONAL demo data**.

> ⚠️ **All data in this project is synthetic demo data.** The handbook must not be read as real institutional rules.

---

## Contents

1. [Assignment objectives](#1-assignment-objectives)
2. [Feature list](#2-feature-list)
3. [Technology stack](#3-technology-stack)
4. [Architecture](#4-architecture)
5. [Installation](#5-installation)
6. [How to run the application](#6-how-to-run-the-application)
7. [How to run tests](#7-how-to-run-tests)
8. [How to run evaluations](#8-how-to-run-evaluations)
9. [Authentication and authorization](#9-authentication-and-authorization)
10. [Approval workflow](#10-approval-workflow)
11. [Audit-log behavior](#11-audit-log-behavior)
12. [Known limitations](#12-known-limitations)
13. [GitHub setup instructions](#13-github-setup-instructions)
14. [Demonstration-video checklist](#14-demonstration-video-checklist)
15. [Assignment comparison](#15-assignment-comparison)

---

## 1. Assignment objectives
Build a student-support agent with: a chat UI, an explicit agent loop, ≥2 functional tools (4 implemented), persistent memory, policy-document retrieval (RAG), context selection, error handling, tracing, and a reproducible evaluation.

## 2. Feature list

| Area | Assignment 1 | Assignment 2 addition |
|------|-------------|----------------------|
| Chat UI | Streamlit chat, student selector, memory viewer/clear, trace viewer + metrics | Sign-in screen, admin console, add-student and password-reset forms, removed demo-question buttons |
| Agent loop | Intent → memory → retrieval → minimal context → bounded LLM/tool loop | Same loop; tool authorization derives student_id from authenticated session |
| Tools | `get_student_record`, `check_fee_status`, `check_scholarship_status`, `create_support_request` | Same tools; `authorize()` rejects cross-student calls and writes audit events |
| Memory | SQLite, per student, deduplicated, relevance-gated, sensitive-data filter | Same; passwords/OTPs/API keys blocked from persistence |
| RAG | Handbook → chunks → embeddings → cosine top-k → only matching chunks reach model | Same |
| Context selection | Question, student scope, chunks, memory, last 2 turns | Same |
| Tracing | One structured trace per request in SQLite | Same; secrets redacted before tracing |
| Evaluation | 17 test cases, `evaluation_results.json` + `report.md` | Same; runs in demo mode without a Groq key |
| Security | Sensitivity filter for secrets | Login, roles, PBKDF2 hashing, own-record authorization, approval workflow, audit log |

## 3. Technology stack
Python 3.10+ · Streamlit · SQLite · Groq API (model name configurable) · scikit-learn TF-IDF embeddings (default, no download) or Sentence-Transformers (optional) · NumPy cosine search · pytest.

**Design notes (honest trade-offs)**
- **Vector search:** exact cosine similarity with NumPy. With ~18 chunks, FAISS adds a dependency with no benefit.
- **Embeddings:** `EMBEDDING_BACKEND=auto` tries Sentence-Transformers (`all-MiniLM-L6-v2`) if installed, otherwise uses the **documented TF-IDF fallback** (word + character n-grams). The backend actually used is shown in the sidebar and in every trace; a fallback reason is displayed, never hidden.
- **Intent classification** is rule-based (deterministic and easy to explain). The LLM still chooses and parameterises tool calls.

## 4. Architecture
```mermaid
flowchart LR
    UI[Streamlit chat UI] --> AG[Agent orchestrator]
    AG --> SF[Sensitivity filter]
    AG --> IN[Intent classifier]
    AG --> MEM[(Memory - SQLite)]
    AG --> RET[Retriever - policy chunks]
    RET --> DOC[data/student_policy.md]
    AG --> CB[Context builder]
    CB --> LLM[Groq LLM or Demo planner]
    LLM -->|tool call| REG[Tool registry: validate + authorize]
    REG --> T1[get_student_record]
    REG --> T2[check_fee_status]
    REG --> T3[check_scholarship_status]
    REG --> T4[create_support_request]
    T1 & T2 & T3 & T4 --> DB[(SQLite)]
    REG -->|result| LLM
    AG --> TR[(Traces - SQLite)]
```

### Agent flow
```mermaid
flowchart TD
    A[Student question] --> B[Scan + redact secrets]
    B -->|secret found| B2[Log safe event, save nothing]
    B --> C[Classify intent]
    C --> D[Save non-sensitive preferences]
    D --> E{Policy question?}
    E -->|yes| F[Retrieve top-k chunks above threshold]
    E -->|no| G[Skip retrieval]
    F --> H[Get relevant memory]
    G --> H
    H --> I[Build minimal context]
    I --> J[LLM step]
    J -->|tool call| K[Validate args, authorize, run tool]
    K --> J
    J -->|final text| L[Answer]
    J -->|error / empty / loop limit| M[Honest fallback message]
    L --> N[Save trace]
    M --> N
```

## 5. Folder structure
```
student-support-agent/
├── app.py                    # Streamlit UI
├── config.py                 # settings from environment
├── agent/    orchestrator.py  intent.py  context_builder.py  tool_registry.py
│             llm_client.py (Groq + Demo)  demo_answers.py  prompts.py
├── tools/    student_tools.py  support_tools.py  common.py
├── memory/   memory_manager.py  sensitivity_filter.py
├── retrieval/ document_loader.py  chunker.py  retriever.py
├── database/ schema.sql  db.py  seed_data.py  init_db.py
├── observability/ tracing.py  metrics.py
├── evaluation/ test_cases.json  run_evaluation.py  evaluation_results.json  report.md
├── data/student_policy.md    # fictional handbook
├── tests/                    # pytest unit tests
├── requirements.txt  requirements-optional.txt  .env.example  .gitignore
```

## 6. Setup (Windows, PowerShell)
Prerequisite: Python 3.10+ (`python --version`). Optional: a free Groq API key from <https://console.groq.com>.

```powershell
cd student-support-agent
python -m venv .venv
.venv\Scripts\Activate.ps1          # if blocked: Set-ExecutionPolicy -Scope Process Bypass
pip install -r requirements.txt
copy .env.example .env              # then edit .env and paste your key
python -m database.init_db          # creates data\student_support.db with synthetic data
streamlit run app.py
```
Open <http://localhost:8501>. Without a key the app runs in **demo mode** (yellow banner). To force it: `DEMO_MODE=1`.

**Configure the API key safely:** put it only in `.env` (git-ignored). Never paste it in code, chat, README or screenshots. If it ever leaks, revoke it in the Groq console.

**Optional neural embeddings:** `pip install -r requirements-optional.txt` (large download).

## 7. Tests and evaluation
```powershell
python -m pytest -q                      # 48 unit tests (tools, memory, retrieval, filter, tracing, agent loop)
python -m evaluation.run_evaluation      # 17 scenarios -> evaluation/evaluation_results.json + report.md
```
The evaluation uses a **temporary database** (your demo DB is untouched), and works in both modes. With a Groq key it tests the real LLM; without one it runs deterministically and the report says so.
Metrics: task accuracy (explicit expectations) vs. task completion (no system failure), average/median latency, API-reported token totals, tool success rate, retrieval success.

> Unit tests of the agent loop use a *scripted fake LLM* to verify control flow (bounds, validation, error handling). They do **not** validate real model reasoning.

## 8. Demo students (synthetic)
| ID | Name | Fee status | Scholarship |
|---|---|---|---|
| STU1001 | Aarav Mehta | Partially paid (₹25,000 due) | Under Review |
| STU1002 | Diya Patel | Paid | Approved (₹15,000) |
| STU1003 | Rohan Shah | Unpaid, overdue | none |
| STU1004 | Ananya Joshi | Partially paid | Rejected |
| STU1005 | Kabir Desai | Paid | Documents Required |
| STU1006 | Meera Trivedi | Partially paid | Submitted |

## 9. Demonstration scenarios
Use the sidebar buttons or type these (pick **STU1002** for 3-5, **STU1001** for the rest):
1. *"What is my current fee status?"* → calls `check_fee_status`, shows real DB values.
2. *"What is the policy if the payment portal fails?"* → retrieves Section 6.1 (see trace).
3. *"Please reply to me in Gujarati and keep answers short."* → saved to memory (sidebar shows it).
4. Click **New conversation** (or restart the app), then *"Which language did I ask you to use?"* → read back from SQLite.
5. *"My password is Hunter2! and my OTP is 482913."* → not stored; check Traces tab: question shows `[REDACTED:...]`.
6. *"Please create a support ticket: my fee receipt is not showing."* → real ticket ID `TKT-YYYYMMDD-XXXXXX` in SQLite.
7. *"What is the hostel curfew time?"* → honest "handbook does not cover it".
8. Failures: set a wrong key in `.env` or unplug the network → friendly message, no stack trace, no invented data (`tests/test_agent_loop.py` covers rate limit / network / auth / empty / malformed cases).

### Example tool calls (as seen in traces)
```json
{"name": "check_fee_status", "args": {"student_id": "<masked in traces>"}}
→ {"ok": true, "data": {"total_fee": 120000.0, "paid_amount": 95000.0, "outstanding_balance": 25000.0, "payment_status": "Partially Paid"}}
{"name": "create_support_request", "args": {"category": "fees", "description": "my fee receipt is not showing"}}
→ {"ok": true, "data": {"ticket_id": "TKT-20261029-1F3A9C", "status": "Open"}}
```

## 10. Memory, retrieval, context, tracing
- **Memory:** only language, answer style, contact method and course interest are stored (one row per student+key, so repeats update rather than duplicate). Relevance table in `memory_manager.py` decides what each question type may see. Sensitive messages save **nothing**; only a category-level security event is logged.
- **Sensitivity filter:** regex for passwords, OTPs, PINs, API keys/tokens, card and 12-digit ID numbers. Best-effort, not a guarantee.
- **Retrieval:** chunks = `###` subsections; cosine top-3 above a threshold tuned on sample questions (TF-IDF 0.28). Below threshold → "not covered", never an invented policy.
- **Context selection:** see `ContextReport` in each trace (`policy_chunks`, `memory_keys`, `history_messages`, `excluded`).
- **Tracing:** trace ID, timestamp, pseudonymous student ref, redacted question, intent, tools (status, duration), retrieved chunk IDs + scores, memory refs, success, latency, model, tokens (`token_source` = `api` or `unavailable`; never estimated), errors.

## 11. Limitations
- Demo mode answers are templates, not AI; it cannot translate to the saved language.
- TF-IDF retrieval is lexical; unusual paraphrases may miss (install Sentence-Transformers for semantic matching, then re-tune `MIN_SCORE`).
- Rule-based intent detection can misclassify unusual phrasing; mixed requests ("fees and scholarship") are handled one intent at a time.
- Regex secret detection can miss exotic formats.
- Groq calls were **not** exercised in the development sandbox (no access to Groq); the Groq path is covered by fake-LLM tests only. Test it with your key and the evaluation script.
- Demo login is a selector, **not authentication** (planned for Assignment 2).

## 12. Troubleshooting
| Problem | Fix |
|---|---|
| Yellow "Demo mode" banner | No/placeholder `GROQ_API_KEY` in `.env`, or `DEMO_MODE=1` |
| "configured AI model is unavailable" | Update `GROQ_MODEL` (see Groq model list) |
| "rejected the configured API key" | Re-create the key; ensure no quotes/spaces in `.env` |
| `ModuleNotFoundError: database` | Run commands from the project root with `python -m ...` |
| Activate.ps1 blocked | `Set-ExecutionPolicy -Scope Process Bypass` |
| Stale/odd demo data | `python -m database.init_db --reset` |
| Retrieval error in sidebar | Check `data/student_policy.md` exists; set `EMBEDDING_BACKEND=tfidf` |

## 13. Security considerations
Secrets only in `.env` (git-ignored, never logged or shown). Parameterised SQL everywhere. Tool arguments validated; tools can only act on the chatting student (`authorize()` in `tool_registry.py`). Secrets are redacted before the LLM, traces, tickets and memory. Errors shown to users are generic; details go to server logs only.

**Assignment 2 extension points:** authentication → replace the sidebar selector and `ToolContext`; authorisation/privacy → extend `authorize()`; approval workflows → use `ToolDef.writes_data`; auditability → extend `traces` / `security_events`.

## 14. Publishing to GitHub safely
```powershell
git init
git status                 # confirm .env and *.db are NOT listed
git add .
git commit -m "Assignment 1: Intelligent Student Support Agent"
# create an EMPTY public repo on github.com, then:
git branch -M main
git remote add origin https://github.com/<your-username>/student-support-agent.git
git push -u origin main
```
Before pushing: `git ls-files | findstr /i ".env"` must show only `.env.example`. If you ever committed a key, revoke it immediately - deleting the file is not enough.

## Assignment 2 — privacy, authorization, approval and audit

This version extends the same Assignment 1 application. It adds a sign-in screen, role-scoped access, an administrator approval console, and a separate audit log.

### Demo sign-in (synthetic data only)
- Student usernames: `stu1001` through `stu1006`
- Student demo password: `Student@123`
- Administrator username: `admin`
- Administrator demo password: `Admin@123`

These are demonstration credentials, not production authentication. Change them before recording your demo by setting `DEMO_STUDENT_PASSWORD` and `DEMO_ADMIN_PASSWORD` in `.env`. Passwords are stored as salted PBKDF2 hashes, not plaintext. For a real institution, replace this local demo login with institutional SSO/MFA and secure session management.

### Assignment 2 safety behaviour
1. The student identity comes from the authenticated session; there is no student selector in the chat UI.
2. Tool execution checks that requested `student_id` matches the signed-in student's ID. The check is in Python tool code, not just the LLM prompt.
3. Students can request an email change for their own record. The request is stored as `pending`; it does not change the record.
4. Only an authenticated `admin` can approve/reject a pending request. Approval executes the change; rejection records `rejected` and does not execute it.
5. `audit_log` records sign-in attempts, change requests, approval/rejection, decision and result. It does not record raw passwords or OTPs. Existing sensitivity filtering remains responsible for persistent memory.
6. Existing traces and evaluation remain available in the student app. The admin view shows pending approvals and recent audit records.

### Run and demo
1. Install dependencies and configure `.env` as in the Assignment 1 setup section.
2. Start with `streamlit run app.py`.
3. Sign in as `stu1001` / `Student@123`; ask for your fee status (allowed).
4. Ask the agent for `STU1002` private details while signed in as `stu1001`; it should be blocked by the tool authorization check.
5. In the sidebar, submit an email-change request. Sign out and sign in as `admin` / `Admin@123`.
6. Reject the request and verify the student's email is unchanged; submit another request and approve it to demonstrate the approved execution path.
7. Show the audit log and Traces & metrics tab. Run `pytest -q` and the existing evaluation command for the final report.

### Security limitation to explain honestly
This is an educational, local demonstration. It uses seeded demo accounts and a shared demo password per role/type; it is not production-ready identity management. Do not use real student data. Production deployment needs SSO/MFA, secure session/cookie settings, account provisioning, rate limiting, secret management, database access controls, and security review.
