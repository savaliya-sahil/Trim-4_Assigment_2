"""Local vector retrieval over policy chunks.

Embedding backends
------------------
* ``sentence-transformers`` (``all-MiniLM-L6-v2``) - used when the package is installed
  and the model can be loaded (needs a one-time model download).
* ``tfidf`` - a documented local fallback: hybrid word-level (lightly stemmed) +
  character n-gram TF-IDF vectors. Needs no download and is fully reproducible.

Search is exact cosine similarity with NumPy (the handbook has ~20 chunks, so FAISS
would add a dependency without any benefit). The backend actually used, and any
fallback reason, are exposed so the UI/traces never pretend something else happened.
"""
from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field

import numpy as np
from sklearn.feature_extraction.text import ENGLISH_STOP_WORDS, TfidfVectorizer
from sklearn.preprocessing import normalize

from retrieval.chunker import Chunk, chunk_markdown
from retrieval.document_loader import load_policy_text

logger = logging.getLogger(__name__)

MIN_SCORE = {"tfidf": 0.28, "sentence-transformers": 0.35}
_EXTRA_STOP = {"policy", "procedure", "student", "students", "please", "tell", "want", "need", "know", "process", "processed", "processing"}
_STOP = set(ENGLISH_STOP_WORDS) | _EXTRA_STOP


class RetrievalError(RuntimeError):
    pass


def _stem(tok: str) -> str:
    for suffix in ("ures", "ure", "ing", "ed", "ies"):
        if tok.endswith(suffix) and len(tok) - len(suffix) >= 3:
            return tok[: -len(suffix)] + ("y" if suffix == "ies" else "")
    if tok.endswith("s") and not tok.endswith("ss") and len(tok) > 3:
        return tok[:-1]
    return tok


def _words(text: str) -> list[str]:
    return [_stem(t) for t in re.findall(r"[a-z0-9]+", text.lower()) if t not in _STOP]


def _clean(text: str) -> str:
    return " ".join(t for t in re.findall(r"[a-z0-9]+", text.lower()) if t not in _STOP)


class _TfidfEmbedder:
    name = "tfidf"

    def __init__(self, corpus: list[str]):
        self.word = TfidfVectorizer(analyzer=_words, sublinear_tf=True)
        self.char = TfidfVectorizer(analyzer="char_wb", ngram_range=(4, 5), sublinear_tf=True, preprocessor=_clean)
        self.word.fit(corpus)
        self.char.fit(corpus)

    def encode(self, texts: list[str]) -> np.ndarray:
        w = self.word.transform(texts).toarray()
        c = self.char.transform(texts).toarray()
        # weighted concatenation: cosine of the result = 0.6*cos_word + 0.4*cos_char
        return normalize(np.hstack([np.sqrt(0.6) * w, np.sqrt(0.4) * c]))


class _SentenceTransformerEmbedder:
    name = "sentence-transformers"

    def __init__(self, corpus: list[str]):
        from sentence_transformers import SentenceTransformer  # optional dependency
        self.model = SentenceTransformer("all-MiniLM-L6-v2")

    def encode(self, texts: list[str]) -> np.ndarray:
        return np.asarray(self.model.encode(texts, normalize_embeddings=True))


@dataclass
class RetrievalResult:
    hits: list[tuple[Chunk, float]] = field(default_factory=list)
    backend: str = ""
    top_score: float = 0.0

    @property
    def empty(self) -> bool:
        return not self.hits


class Retriever:
    def __init__(self, chunks: list[Chunk], backend: str = "auto"):
        if not chunks:
            raise RetrievalError("No policy chunks were created from the handbook.")
        self.chunks = chunks
        self.fallback_reason: str | None = None
        corpus = [c.embed_text for c in chunks]
        self._embedder = self._make_embedder(backend, corpus)
        self.backend = self._embedder.name
        self.min_score = MIN_SCORE[self.backend]
        try:
            self._matrix = self._embedder.encode(corpus)
        except Exception as exc:  # pragma: no cover - defensive
            raise RetrievalError(f"Could not build the vector index: {type(exc).__name__}") from exc

    def _make_embedder(self, backend: str, corpus: list[str]):
        if backend in ("auto", "sentence-transformers"):
            try:
                return _SentenceTransformerEmbedder(corpus)
            except Exception as exc:
                self.fallback_reason = f"sentence-transformers unavailable ({type(exc).__name__}); using TF-IDF fallback"
                logger.warning(self.fallback_reason)
        return _TfidfEmbedder(corpus)

    def search(self, query: str, top_k: int = 3) -> RetrievalResult:
        if not query or not query.strip():
            return RetrievalResult(backend=self.backend)
        q = self._embedder.encode([query])[0]
        scores = self._matrix @ q
        order = np.argsort(-scores)[:top_k]
        hits = [(self.chunks[i], float(scores[i])) for i in order if scores[i] >= self.min_score]
        return RetrievalResult(hits, self.backend, float(scores[order[0]]) if len(order) else 0.0)


def build_retriever(backend: str = "auto") -> Retriever:
    """Load the handbook, chunk it and build the vector index (raises clear errors)."""
    return Retriever(chunk_markdown(load_policy_text()), backend)
