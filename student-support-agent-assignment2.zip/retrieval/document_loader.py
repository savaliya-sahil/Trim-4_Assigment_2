"""Load the policy document from disk with a clear error if it is missing."""
from __future__ import annotations

from pathlib import Path

from config import POLICY_PATH


class DocumentLoadError(RuntimeError):
    pass


def load_policy_text(path: Path | str | None = None) -> str:
    p = Path(path) if path else POLICY_PATH
    if not p.exists():
        raise DocumentLoadError(f"Policy document not found: {p.name}")
    text = p.read_text(encoding="utf-8").strip()
    if not text:
        raise DocumentLoadError("Policy document is empty.")
    return text
