"""Split the markdown handbook into meaningful chunks (one per ``###`` sub-section)."""
from __future__ import annotations

import re
from dataclasses import dataclass

_H2 = re.compile(r"^##\s+(\d+)\.\s+(.*)$")
_H3 = re.compile(r"^###\s+(\d+\.\d+)\s+(.*)$")


@dataclass(frozen=True)
class Chunk:
    chunk_id: str      # e.g. "policy::6.1"
    section: str       # parent section title, e.g. "Payment Portal Troubleshooting"
    title: str         # sub-section title
    text: str          # body text

    @property
    def embed_text(self) -> str:
        return f"{self.section}. {self.title}. {self.text}"

    @property
    def section_number(self) -> str:
        return self.chunk_id.split("::", 1)[1].split(".")[0]


def chunk_markdown(markdown: str) -> list[Chunk]:
    chunks: list[Chunk] = []
    section_title = "Handbook"
    cur_id: str | None = None
    cur_title = ""
    buf: list[str] = []

    def flush() -> None:
        nonlocal buf
        body = " ".join(line.strip() for line in buf if line.strip()).strip()
        if cur_id and body:
            chunks.append(Chunk(cur_id, section_title, cur_title, body))
        buf = []

    for line in markdown.splitlines():
        if (m := _H2.match(line)):
            flush()
            section_title, cur_id, cur_title = m.group(2).strip(), None, ""
        elif (m := _H3.match(line)):
            flush()
            cur_id, cur_title = f"policy::{m.group(1)}", m.group(2).strip()
        elif cur_id and not line.startswith("#"):
            buf.append(line)
    flush()
    return chunks
