"""Streamlit chat UI for the Intelligent Student Support Agent.

Run with:  streamlit run app.py
"""
from __future__ import annotations

import logging
import uuid

import pandas as pd
import streamlit as st

from agent.orchestrator import StudentSupportAgent
from config import load_settings
from database.db import connect
from database.init_db import init_database
from memory import memory_manager
from observability.metrics import summarize_traces
from observability.tracing import list_traces
from retrieval.retriever import build_retriever
from security import authenticate, ensure_demo_accounts, request_email_change, list_approvals, review_approval, recent_audit, audit
from security import create_student_account, reset_student_password

settings = load_settings()
logging.basicConfig(level=getattr(logging, settings.log_level, logging.INFO))

st.set_page_config(page_title="Student Support Agent", page_icon="🎓", layout="wide")

DEMO_PROMPTS = [
    "What is my current fee status?",
    "What is the policy if the payment portal fails?",
    "Please reply to me in Gujarati and keep answers short.",
    "Which language did I ask you to use?",
    "My password is Hunter2! and my OTP is 482913. Please remember them.",
    "Please create a support ticket: my fee receipt for this term is not showing in the portal.",
    "What is the hostel curfew time?",
    "What is the status of my scholarship application?",
]


@st.cache_resource(show_spinner="Starting up: database and policy index...")
def get_agent() -> StudentSupportAgent:
    init_database()  # idempotent: creates tables, inserts sample rows only if missing
    retriever, error = None, None
    try:
        retriever = build_retriever(settings.embedding_backend)
    except Exception as exc:  # shown honestly in the sidebar; policy answers will say retrieval is unavailable
        logging.exception("Retriever initialisation failed")
        error = f"{type(exc).__name__}: {exc}"
    return StudentSupportAgent(settings, retriever, error)


def load_students() -> list[tuple[str, str]]:
    with connect() as conn:
        rows = conn.execute("SELECT student_id, full_name, program FROM students ORDER BY student_id").fetchall()
    return [(r["student_id"], f"{r['student_id']} - {r['full_name']} ({r['program']})") for r in rows]


def new_conversation() -> None:
    st.session_state.messages = []
    st.session_state.session_id = uuid.uuid4().hex[:8]


def reset_if_student_changed() -> None:
    new_conversation()


agent = get_agent()
students = load_students()
ensure_demo_accounts()
labels = dict(students)

# Assignment 2: real login form replaces Assignment 1's student selector.
if "auth_user" not in st.session_state:
    st.session_state.auth_user = None
if not st.session_state.auth_user:
    st.title("🎓 Student Support Agent — Sign in")
    st.info("Assignment 2 demonstration authentication. Synthetic demo accounts only; this is not institutional SSO.")
    with st.form("login_form"):
        username = st.text_input("Username", placeholder="stu1001 or admin")
        password = st.text_input("Password", type="password")
        submitted = st.form_submit_button("Sign in", type="primary")
    with st.expander("Demo credentials (synthetic data)"):
        st.markdown("- Student usernames: `stu1001` through `stu1006` — password: `Student@123`\n- Administrator username: `admin` — password: `Admin@123`\n\nChange these using `DEMO_STUDENT_PASSWORD` and `DEMO_ADMIN_PASSWORD` in `.env` before recording your demo.")
    if submitted:
        user = authenticate(username, password)
        if user:
            st.session_state.auth_user = user
            st.session_state.messages = []
            st.session_state.session_id = uuid.uuid4().hex[:8]
            st.rerun()
        else:
            st.error("Sign-in failed. Check username and password.")
    st.stop()

user = st.session_state.auth_user
if user.get("role") == "admin":
    st.title("🛡️ Administrator Approval Console")
    st.caption("Human approval gate — sensitive changes execute only after explicit approval.")
    if st.button("Sign out"):
        audit(user['username'], user['role'], 'logout', None, 'allowed', 'success', {})
        st.session_state.auth_user = None
        st.rerun()
    st.subheader("➕ Add new student")
    with st.form("add_student_form", clear_on_submit=True):
        c1, c2 = st.columns(2)
        n_name = c1.text_input("Full name")
        n_email = c2.text_input("Email", placeholder="name@example.edu")
        n_program = c1.text_input("Program", placeholder="B.Tech Computer Engineering")
        n_sem = c2.number_input("Semester", min_value=1, max_value=12, value=1)
        n_year = c1.number_input("Enrollment year", min_value=2000, max_value=2100, value=2026)
        n_pass = c2.text_input("Password (leave blank to auto-generate)")
        n_fee = c1.number_input("Total fee (optional)", min_value=0.0, value=0.0, step=1000.0)
        n_term = c2.text_input("Fee term", placeholder="2026-Autumn")
        n_due = c1.text_input("Fee due date", placeholder="2026-12-31")
        add_clicked = st.form_submit_button("Create student and login", type="primary")
    if add_clicked:
        try:
            created = create_student_account(user, n_name, n_email, n_program, int(n_sem), int(n_year),
                                             n_pass, float(n_fee), n_term, n_due)
            st.session_state.last_created = created
        except Exception as exc:
            st.session_state.last_created = None
            st.error(str(exc))
    if st.session_state.get("last_created"):
        c = st.session_state.last_created
        st.success(f"Student created. Student ID: {c['student_id']}")
        st.code(f"Username: {c['username']}\nPassword: {c['password']}")
        st.caption("Passwords are stored only as hashes, so note this one now. You can set a new one below.")

    st.subheader("🔑 Reset a student password")
    with st.form("reset_pw_form", clear_on_submit=True):
        all_students = load_students()
        sel = st.selectbox("Student", [s[0] for s in all_students], format_func=lambda s: labels.get(s, s))
        new_pw = st.text_input("New password (leave blank to auto-generate)")
        reset_clicked = st.form_submit_button("Reset password")
    if reset_clicked:
        try:
            pw = reset_student_password(user, sel, new_pw)
            st.success("Password updated.")
            st.code(f"Username: {sel.lower()}\nPassword: {pw}")
        except Exception as exc:
            st.error(str(exc))

    st.subheader("Pending approval requests")
    pending = list_approvals("pending")
    if not pending:
        st.success("No pending requests.")
    for req in pending:
        payload = __import__('json').loads(req['payload_json'])
        with st.container(border=True):
            st.markdown(f"**Request:** `{req['request_id']}` · **Student:** {req['full_name']} (`{req['student_id']}`)")
            st.write(f"Action: `{req['action_type']}` · Requested by: `{req['requested_by']}` · Created: {req['created_at']}")
            st.write("Proposed email:", payload.get('new_email', '[not shown]'))
            note = st.text_input("Review note", key=f"note_{req['request_id']}")
            c1,c2=st.columns(2)
            if c1.button("Approve & execute", key=f"approve_{req['request_id']}", type="primary"):
                ok, message = review_approval(user, req['request_id'], True, note)
                (st.success if ok else st.error)(message)
                st.rerun()
            if c2.button("Reject (do not execute)", key=f"reject_{req['request_id']}"):
                ok, message = review_approval(user, req['request_id'], False, note)
                (st.success if ok else st.error)(message)
                st.rerun()
    st.subheader("Recent audit log")
    st.dataframe(pd.DataFrame(recent_audit()), width="stretch", hide_index=True)
    st.stop()

student_id = user["student_id"]
if "messages" not in st.session_state:
    new_conversation()

# ----------------------------------------------------------------- sidebar
with st.sidebar:
    st.title("🎓 Student Support Agent")
    st.caption("Agentic AI Engineering - Assignment 2. All data is **synthetic demo data**.")
    st.write(f"Signed in: **{labels.get(student_id, student_id)}**")
    if st.button("Sign out", width="stretch"):
        audit(user['username'], user['role'], 'logout', student_id, 'allowed', 'success', {})
        st.session_state.auth_user = None
        st.rerun()
    if st.button("➕ New conversation", width="stretch"):
        new_conversation()
        st.rerun()

    if agent.mode == "groq":
        st.success(f"LLM mode: Groq - `{agent.model_label}`")
    else:
        st.warning("**Demo mode** - no LLM is used. Tools, retrieval and memory are real; wording is template-based. "
                   "Add `GROQ_API_KEY` to `.env` for real LLM responses.")
    if agent.retriever:
        note = f" ({agent.retriever.fallback_reason})" if agent.retriever.fallback_reason else ""
        st.caption(f"Retrieval backend: `{agent.retriever.backend}`{note}")
    else:
        st.error("Policy retrieval unavailable: " + (agent.retriever_error or "unknown error"))

    with st.expander("What can I ask?", expanded=False):
        st.markdown("- 💳 Fee status & balance\n- 🎓 Scholarship status\n- 👤 Student profile\n"
                    "- 🎫 Create a support ticket\n- 📘 Handbook policies (fees, scholarships, courses, portal)\n"
                    "- 🧠 Remember your language / style preferences")

    st.subheader("🔐 Sensitive change (approval required)")
    with st.form("email_change_form"):
        new_email = st.text_input("Request a change to your account email", placeholder="new.email@example.edu")
        submitted_change = st.form_submit_button("Submit for administrator approval")
    if submitted_change:
        try:
            request_id = request_email_change(user, new_email)
            st.success(f"Request submitted: {request_id}. The email will NOT change until an administrator approves it.")
        except (ValueError, PermissionError) as exc:
            st.error(str(exc))

    st.subheader("🧠 Persistent memory")
    try:
        memories = memory_manager.list_memories(student_id)
    except Exception:
        memories = []
        st.error("Could not read memory.")
    if memories:
        for m in memories:
            st.markdown(f"- **{m['label']}**: {m['mem_value']}")
        if st.button("Clear demo memory", width="stretch"):
            memory_manager.clear_memories(student_id)
            st.rerun()
    else:
        st.caption("Nothing saved for this student yet.")

    show_debug = st.toggle("Show trace under each answer", value=True)

# ----------------------------------------------------------------- main
tab_chat, tab_traces = st.tabs(["💬 Chat", "📊 Traces & metrics"])

with tab_chat:
    st.subheader(f"Chatting as {labels[student_id]}")
    for msg in st.session_state.messages:
        with st.chat_message(msg["role"]):
            st.markdown(msg["content"])
            if msg["role"] == "assistant" and msg.get("trace"):
                st.caption(("🧪 demo mode" if msg["mode"] == "demo" else "🤖 LLM") +
                           f" · {msg['trace']['latency_ms']} ms · intent: {msg['trace']['intent']}")
                if show_debug:
                    with st.expander("🔍 Trace / evidence"):
                        st.json(msg["trace"])

    typed = st.chat_input("Ask about fees, scholarships, courses, policies...")
    prompt = typed or st.session_state.pop("queued_prompt", None)
    if prompt:
        history = [{"role": m["role"], "content": m["content"]} for m in st.session_state.messages]
        st.session_state.messages.append({"role": "user", "content": prompt})
        with st.spinner("Thinking..."):
            resp = agent.handle(prompt, student_id, st.session_state.session_id, history)
        st.session_state.messages.append({"role": "assistant", "content": resp.answer,
                                          "trace": resp.trace, "mode": resp.mode})
        st.rerun()

with tab_traces:
    try:
        traces = list_traces(100)
    except Exception:
        traces = []
        st.error("Could not load traces.")
    if not traces:
        st.info("No traces yet. Ask the agent something first.")
    else:
        summary = summarize_traces(traces)
        c1, c2, c3, c4 = st.columns(4)
        c1.metric("Requests", summary["requests"])
        c2.metric("Completion rate", f"{summary['completion_rate']:.0%}")
        c3.metric("Avg latency (ms)", summary["avg_latency_ms"])
        c4.metric("Tool success", f"{summary['tool_success_rate']:.0%}" if summary["tool_success_rate"] is not None else "n/a")
        st.caption(f"Input tokens: {summary['total_input_tokens_api']} · Output tokens: {summary['total_output_tokens_api']}. "
                   + summary["token_note"])
        df = pd.DataFrame([{
            "time": t["timestamp"], "trace_id": t["trace_id"], "student": t["student_ref"], "intent": t["intent"],
            "tools": ", ".join(x["name"] for x in t["tools"]) or "-", "retrieval": t["retrieval_used"],
            "chunks": ", ".join(c["id"].split("::")[1] for c in t["retrieved_chunks"]) or "-",
            "success": t["success"], "latency_ms": t["latency_ms"], "model": t["model"],
            "question (redacted)": t["question_redacted"][:70]} for t in traces])
        st.dataframe(df, width="stretch", hide_index=True)
        chosen = st.selectbox("Inspect a trace", [t["trace_id"] for t in traces])
        st.json(next(t for t in traces if t["trace_id"] == chosen))
