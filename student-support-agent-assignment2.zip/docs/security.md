# Security — Intelligent Student Support Agent

This document explains authentication, authorization, protected records, approval enforcement, audit logging, and sensitive-data handling. All data is synthetic / fictional demo data.

> **Limitation:** This is an educational demonstration, not production authentication. Demo accounts use shared default passwords unless changed in `.env`. A real deployment needs institutional SSO/MFA, secure session controls, rate limiting, account provisioning, and a formal security review.

## Authentication

- **Login form:** Streamlit sign-in page with username and password fields.
- **Roles:** `student` and `admin`. Students access their own data; administrators manage accounts and approvals.
- **Password hashing:** Passwords are salted with PBKDF2-HMAC-SHA256 (240,000 iterations). Raw passwords are never stored in SQLite or logs.
- **Demo accounts:** `ensure_demo_accounts()` creates accounts for all seeded students (username = lowercased student ID, e.g. `stu1001`) and one administrator (`admin`). Default passwords are configurable via `DEMO_STUDENT_PASSWORD` and `DEMO_ADMIN_PASSWORD` in `.env`.
- **Session identity:** After sign-in, the user object (username, role, student_id) is stored in Streamlit session state. The student ID used for all tool calls comes from this verified context, not from user input.
- **Logout:** Signing out clears the session state and redirects to the login page.
- **Inactive accounts:** Accounts can be deactivated (`active=0`) and will be denied login.

## Authorization

Authorization is enforced in backend code, not merely hidden in the UI:

1. **Tool authorization:** `authorize()` in `tool_registry.py` rejects any tool call whose `student_id` does not match the authenticated student's ID.
2. **Own-record privacy:** Students can only access their own fee, scholarship, and profile records.
3. **Cross-student denial:** Attempting to access another student's record returns `not_authorized` and is logged to the audit trail.
4. **Admin-only operations:** `create_student_account()` and `reset_student_password()` require the `admin` role. Students attempting these operations receive `PermissionError`.
5. **Unauthenticated calls:** All protected operations require an authenticated principal. Tool arguments are never trusted without checking authorization.

## Sensitive Action Approval Workflow

Email address changes require administrator approval:

1. **Request:** An authenticated student submits a new email address. The request is validated (email format, student role).
2. **Store:** The request is stored with a unique ID (`APR-...`), the requester's identity, the proposed email, and status `PENDING`.
3. **Pending:** No change is executed while the request is pending.
4. **Review:** An authorized administrator can approve or reject the request with a review note.
5. **Execute:** Approval updates the student's email and sets status to `EXECUTED`. Rejection sets status to `REJECTED` with no data change.
6. **Self-approval prevention:** A student cannot approve their own request — only an `admin` can.
7. **Idempotency:** A request already `executed` or `rejected` cannot be re-executed.

## Audit Logging

Security-relevant events are recorded in the `audit_log` table:

- Successful login
- Failed login attempts
- Logout
- Access-denied events (cross-student tool calls, unauthorized admin operations)
- Sensitive-action request creation
- Approval / rejection decisions
- Successful execution of approved actions
- Failed execution attempts

Each event records: timestamp, event type, actor identity, target record/request ID, outcome, and correlation/request ID. Passwords, OTPs, API keys, and session secrets are never logged.

Audit logs are exposed only through the administrator console; ordinary students cannot view them.

## Sensitive Data Handling

- **Memory:** Only non-sensitive preferences (language, style, contact, course interest) are persisted. Passwords, OTPs, API keys, and tokens are detected by the sensitivity filter and blocked before storage.
- **Traces:** Questions are redacted before tracing. Secret values are replaced with `[REDACTED:category]` placeholders.
- **Audit logs:** The `details_json` field never contains raw secrets.
- **Support tickets:** Descriptions are redacted before storage.

## Demo Account Credentials

| Role | Username | Password (default) |
|------|----------|-------------------|
| Student | `stu1001` through `stu1006` | `Student@123` |
| Administrator | `admin` | `Admin@123` |

Change defaults using `DEMO_STUDENT_PASSWORD` and `DEMO_ADMIN_PASSWORD` in `.env` before recording demonstrations.
