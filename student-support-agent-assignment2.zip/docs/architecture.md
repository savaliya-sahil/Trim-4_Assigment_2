# Architecture — Intelligent Student Support Agent

This document explains the application architecture, agent loop, tools, memory, retrieval, tracing, and evaluation. All data is synthetic / fictional demo data.

## Overview

The system is a Streamlit-based chat application that acts as an AI agent for student support. It answers questions about fees, scholarships, courses, support tickets, and handbook policies. The agent decides whether to answer directly, call a tool, retrieve policy text, use remembered preferences, ask for missing details, or honestly say it does not know.

```
UI[Streamlit chat UI] --> AG[Agent orchestrator]
AG --> SF[Sensitivity filter]
AG --> IN[Intent classifier]
AG --> MEM[(Memory - SQLite)]
AG --> RET[Retriever - policy chunks]
RET --> DOC[data/student_policy.md]
AG --> CB[Context builder]
CB --> LLM[Groq LLM or Demo planner]
LLM -->|tool call| REG[Tool registry: validate + authorize]
REG --> T1[get_student_record]
REG --> T2[check_fee_status]
REG --> T3[check_scholarship_status]
REG --> T4[create_support_request]
T1 & T2 & T3 & T4 --> DB[(SQLite)]
REG -->|result| LLM
AG --> TR[(Traces - SQLite)]
```

## Modules

| Module | Responsibility |
|--------|---------------|
| `app.py` | Streamlit UI: sign-in, chat, traces/metrics, admin console |
| `agent/orchestrator.py` | Bounded agent loop: scan → classify → retrieve → memory → context → LLM → tools → answer → trace |
| `agent/intent.py` | Rule-based intent classification |
| `agent/context_builder.py` | Minimal context selection (question, student scope, chunks, memory, last 2 turns) |
| `agent/tool_registry.py` | Tool schemas, argument validation, authorization hook, safe execution |
| `agent/llm_client.py` | Groq LLM backend and deterministic DemoLLM planner |
| `agent/demo_answers.py` | Template answers for demo mode |
| `agent/prompts.py` | System prompt and tool nudge |
| `tools/student_tools.py` | Read-only tools: profile, fee status, scholarship status |
| `tools/support_tools.py` | Write tool: create support ticket |
| `tools/common.py` | Shared helpers: validation, DB error handling |
| `memory/memory_manager.py` | Persistent non-sensitive memory (language, style, contact, course) |
| `memory/sensitivity_filter.py` | Secret detection and redaction |
| `database/db.py` | SQLite connection helper (parameterised queries) |
| `database/schema.sql` | Database schema |
| `database/init_db.py` | Idempotent database initialization |
| `database/seed_data.py` | Synthetic demo data |
| `observability/tracing.py` | Structured per-request traces in SQLite |
| `observability/metrics.py` | Aggregate trace metrics |
| `retrieval/retriever.py` | TF-IDF or sentence-transformers cosine search over policy chunks |
| `security.py` | Authentication, authorization, approval workflow, audit logging |

## Agent Loop

1. **Scan + redact** — the question is scanned for secrets (passwords, OTPs, API keys, card numbers). Secrets are redacted and never stored.
2. **Classify intent** — rule-based classifier determines the question type (fee, scholarship, record, support, policy, memory, preference, greeting).
3. **Save preferences** — non-sensitive preferences are extracted and upserted into memory.
4. **Retrieve** — if the intent needs policy evidence, relevant handbook chunks are retrieved (top-k, above threshold).
5. **Fetch memory** — relevant non-sensitive memories are loaded for the student.
6. **Build context** — the smallest useful prompt is constructed: question, student ID scope, retrieved chunks, relevant memory, optional last 2 turns.
7. **LLM step** — the model (Groq or Demo) answers or calls a tool.
8. **Tool execution** — the tool registry validates arguments, authorizes (student can only access own records), and executes.
9. **Finalise** — the answer is saved with a structured trace.

## Tools

| Tool | Description | Authorization |
|------|-------------|---------------|
| `get_student_record` | Profile: name, program, semester, enrollment status | Student's own record only |
| `check_fee_status` | Fee total, paid, outstanding, due date, status | Student's own record only |
| `check_scholarship_status` | Scholarship applications and status | Student's own record only |
| `create_support_request` | Creates a support ticket | Student's own record only |

Every tool call is validated against a JSON schema and authorized by `authorize()` in `tool_registry.py`, which rejects any call whose `student_id` does not match the authenticated student.

## Memory

Only four low-risk preference types are stored: preferred language, communication style, contact method, course interest. Memory is relevance-gated per intent. Sensitive messages save nothing — only a category-level security event is logged.

## Retrieval

The handbook (`data/student_policy.md`) is split into `###` sub-section chunks. Embeddings use TF-IDF by default (sentence-transformers optional). Cosine search returns top-k chunks above a relevance threshold. Only matching chunks reach the model.

## Tracing

One structured trace per request is stored in SQLite. Each trace includes: trace ID, timestamp, pseudonymous student reference, redacted question, intent, tools (status, duration), retrieved chunks + scores, memory references, success, latency, model, tokens (API-reported only), errors.

## Evaluation

17 test cases in `evaluation/test_cases.json` are run by `evaluation/run_evaluation.py` against a temporary database. Results are written to `evaluation/evaluation_results.json` and `evaluation/report.md`. The evaluation runs in demo mode (deterministic) unless a real Groq API key is configured.

## GitHub Actions

`.github/workflows/test.yml` runs the full test suite and evaluation on every push/PR across Python 3.10–3.13. No real Groq API key is required; tests run in deterministic demo mode.
