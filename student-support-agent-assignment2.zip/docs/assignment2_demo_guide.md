# Assignment 2 Demonstration Guide

Step-by-step script for demonstrating the security features of the Intelligent Student Support Agent.

## Prerequisites

1. Install dependencies: `pip install -r requirements.txt`
2. Initialize the database: `python -m database.init_db`
3. Run the app: `streamlit run app.py`
4. Open the URL printed by Streamlit (typically `http://localhost:8501`)

## Demo Script

### 1. Student login

Open the app. You will see the sign-in page.

- Sign in as `stu1001` / `Student@123` (Aarav Mehta).
- Verify the chat interface shows "Signed in: Aarav Mehta (STU1001)".
- Sign out and sign in as `admin` / `Admin@123`. Verify the Administrator Approval Console appears.

### 2. Access to the student's own record

Signed in as `stu1001`, ask:

> "What is my current fee status?"

Verify the agent returns Aarav's fee data (₹120,000 total, ₹95,000 paid, ₹25,000 outstanding, Partially Paid).

### 3. Attempted access to another student's record

Signed in as `stu1001`, the agent will only answer questions scoped to STU1001. The tool authorization blocks any attempt to query another student's ID. You can verify this in the Traces tab: a cross-student tool call shows `error_code: not_authorized`.

### 4. Sensitive-action request

Signed in as `stu1001`, use the sidebar "Sensitive change (approval required)" form:

- Enter a new email: `new.aarav@example.edu`
- Click "Submit for administrator approval"
- Verify a request ID is shown (e.g. `APR-...`)
- Verify the student's email in the database is still `aarav.mehta@example.edu` (pending = not executed)

### 5. Rejected request — proof no change occurred

Sign in as `admin` / `Admin@123`.

- Open the Administrator Approval Console.
- Find the pending request for `stu1001`.
- Click "Reject (do not execute)" with a note.
- Verify the status becomes `rejected`.
- Verify the student's email is still `aarav.mehta@example.edu`.

### 6. Approved request — proof the change occurred

Have `stu1001` submit another email change request (e.g. `updated.aarav@example.edu`).

- Sign in as `admin`.
- Approve the request with a note.
- Verify the status becomes `executed`.
- Query the database: `SELECT email FROM students WHERE student_id='STU1001'` should now show `updated.aarav@example.edu`.

### 7. Audit logs

Signed in as `admin`, open the Administrator Approval Console → "Recent audit log".

Verify entries for:
- Login (allowed/denied)
- `request_change_email`
- `review_approval` (approved/rejected)
- Access-denied events

Verify no plaintext passwords appear in the audit log.

### 8. Sensitive-information filtering

Signed in as `stu1001`, type in chat:

> "My password is Hunter2! and my OTP is 482913. Please remember them."

Verify:
- The agent does not save anything to memory.
- The Traces tab shows `[REDACTED:password]` and `[REDACTED:otp]` instead of the real values.
- The `student_memories` table is empty for this student.

### 9. Regression tests and evaluation

Run:

```powershell
python -m pytest -q
DEMO_MODE=1 python -m evaluation.run_evaluation
```

Verify:
- All unit tests pass (52 tests after Assignment 2 changes).
- All 17 evaluation cases pass.
