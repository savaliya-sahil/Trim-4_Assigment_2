# Student Handbook and Policies (DEMO DOCUMENT)

> **FICTIONAL DEMONSTRATION CONTENT.** These policies were written for a college assignment.
> They are examples only and must NOT be interpreted as the rules of any real institution.

## 1. Fee Payment Procedures

### 1.1 Fee payment methods
Tuition and other fees can be paid through the Student Payment Portal using UPI, net banking, or a debit or credit card. Offline payment is accepted at the Accounts Office counter by demand draft. Online payments are credited to the student account within 2 working days.

### 1.2 Instalments
Students may pay the term fee in up to three instalments: 50% at the start of the term, 30% by mid-term, and the remaining 20% on or before the due date shown in the portal.

### 1.3 Payment receipts
A fee receipt is generated within 24 hours of a successful payment. Receipts can be downloaded from the "My Fees" page of the portal. If a receipt is missing after 24 hours, raise a support ticket in the "fees" category.

## 2. Late Fees and Refunds

### 2.1 Late fee policy
If fees remain unpaid after the due date, a late fee of 2% of the outstanding balance is charged for each week of delay, up to a maximum of 10%. A student may request a one-time late fee waiver per academic year by writing to the Accounts Office within 7 days of the due date.

### 2.2 Refund policy
Refunds are available only for excess or duplicate payments and must be requested within 30 days of payment. Approved refunds are processed within 10 working days to the original payment method. Tuition fees are not refundable after the first two weeks of the term.

## 3. Scholarship Application Procedure

### 3.1 Scholarship eligibility
Merit scholarships require a minimum CGPA of 8.0 in the previous year. Need-based aid requires a family annual income below INR 5,00,000. A student may hold only one scholarship at a time.

### 3.2 How to apply for a scholarship
Apply through the Scholarship section of the student portal during the application window, which runs from 1 August to 30 September. Required documents are the previous year's marksheet, an identity proof, a bank passbook copy, and an income certificate for need-based aid.

### 3.3 Scholarship application statuses
An application can be Submitted, Under Review, Documents Required, Approved, or Rejected. The committee review takes about 15 working days. When the status is Documents Required, upload the missing documents within 7 days.

### 3.4 Scholarship renewal and appeals
Scholarships are renewed every year if the student maintains a CGPA of at least 7.5. A rejected application can be appealed to the Scholarship Committee within 10 days of the decision.

## 4. Support Request Procedure

### 4.1 Raising a support ticket
Students can raise a support ticket in one of five categories: fees, scholarship, course, technical, or general. Each ticket receives a unique ID in the format TKT-YYYYMMDD-XXXXXX and starts with the status Open.

### 4.2 Response times
Every ticket is acknowledged within 1 working day. Most tickets are resolved within 5 working days. Urgent fee-related tickets are resolved within 2 working days.

### 4.3 Escalation
If a ticket is not resolved within 5 working days, the student may escalate it to the Student Affairs Office at studentaffairs@example.edu, quoting the ticket ID.

## 5. Course Change Procedure

### 5.1 Eligibility and deadline for a course change
A course change request must be submitted within the first 2 weeks of the semester. The student must have at least 75% attendance and no pending disciplinary action.

### 5.2 Steps to change a course
First meet the academic advisor to discuss the change. Next submit the Course Change Form through the portal. The Head of Department must approve the request. Any fee difference between the old and new course is adjusted in the next fee instalment.

### 5.3 Elective swaps and course withdrawal
An elective can be swapped within the first 10 days of the semester. Withdrawing from a course after week 6 results in a "W" grade on the transcript.

## 6. Payment Portal Troubleshooting

### 6.1 Payment portal failure or downtime
If the payment portal fails or is unavailable, wait 30 minutes and try again, use a different browser or clear the browser cache, and check the portal status page. Do not pay repeatedly. If money was deducted but the payment does not show, keep the bank transaction reference and raise a support ticket in the "fees" category. The Accounts Office reconciles such payments within 3 working days. Late fees are waived for payments that were blocked by documented portal downtime.

### 6.2 Portal login problems
Use the "Forgot password" link on the login page. A reset link is sent only to the registered student email address. University staff will never ask for a password or OTP.

## 7. Credential Safety

### 7.1 Protecting passwords and OTPs
Never share a password, OTP, PIN, or API key with anyone, including the support assistant. The assistant does not store such information.
