-- Schema for the Intelligent Student Support Agent (all data is SYNTHETIC demo data).
CREATE TABLE IF NOT EXISTS students (
    student_id        TEXT PRIMARY KEY,
    full_name         TEXT NOT NULL,
    email             TEXT,
    program           TEXT NOT NULL,
    semester          INTEGER,
    enrollment_year   INTEGER,
    enrollment_status TEXT NOT NULL DEFAULT 'Active'
);

CREATE TABLE IF NOT EXISTS fees (
    fee_id       INTEGER PRIMARY KEY AUTOINCREMENT,
    student_id   TEXT NOT NULL REFERENCES students(student_id),
    term         TEXT NOT NULL,
    total_fee    REAL NOT NULL CHECK (total_fee >= 0),
    paid_amount  REAL NOT NULL DEFAULT 0 CHECK (paid_amount >= 0),
    due_date     TEXT NOT NULL,
    UNIQUE (student_id, term)
);

CREATE TABLE IF NOT EXISTS scholarships (
    scholarship_id   INTEGER PRIMARY KEY AUTOINCREMENT,
    student_id       TEXT NOT NULL REFERENCES students(student_id),
    scholarship_name TEXT NOT NULL,
    status           TEXT NOT NULL CHECK (status IN
                     ('Submitted','Under Review','Documents Required','Approved','Rejected')),
    amount           REAL,
    applied_on       TEXT,
    remarks          TEXT,
    UNIQUE (student_id, scholarship_name)
);

CREATE TABLE IF NOT EXISTS support_requests (
    ticket_id   TEXT PRIMARY KEY,
    student_id  TEXT NOT NULL REFERENCES students(student_id),
    category    TEXT NOT NULL,
    description TEXT NOT NULL,
    status      TEXT NOT NULL DEFAULT 'Open',
    created_at  TEXT NOT NULL
);

-- Persistent, non-sensitive memory. One row per (student, key): upserts dedupe.
CREATE TABLE IF NOT EXISTS student_memories (
    memory_id  INTEGER PRIMARY KEY AUTOINCREMENT,
    student_id TEXT NOT NULL,
    mem_key    TEXT NOT NULL,
    mem_value  TEXT NOT NULL,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    UNIQUE (student_id, mem_key)
);

-- Structured traces (secrets are redacted before insert).
CREATE TABLE IF NOT EXISTS traces (
    trace_id      TEXT PRIMARY KEY,
    created_at    TEXT NOT NULL,
    student_ref   TEXT,
    intent        TEXT,
    success       INTEGER,
    latency_ms    REAL,
    model         TEXT,
    input_tokens  INTEGER,
    output_tokens INTEGER,
    trace_json    TEXT NOT NULL
);

-- Safe diagnostics only: the sensitive VALUE is never stored, just its category.
CREATE TABLE IF NOT EXISTS security_events (
    event_id    INTEGER PRIMARY KEY AUTOINCREMENT,
    created_at  TEXT NOT NULL,
    student_ref TEXT,
    event_type  TEXT NOT NULL,
    categories  TEXT,
    trace_id    TEXT
);

CREATE INDEX IF NOT EXISTS idx_fees_student ON fees(student_id);
CREATE INDEX IF NOT EXISTS idx_sch_student ON scholarships(student_id);
CREATE INDEX IF NOT EXISTS idx_tickets_student ON support_requests(student_id);
CREATE INDEX IF NOT EXISTS idx_traces_created ON traces(created_at);


-- Assignment 2: demo authentication, approval workflow, and audit trail.
CREATE TABLE IF NOT EXISTS auth_users (
    username TEXT PRIMARY KEY,
    role TEXT NOT NULL CHECK (role IN ('student','admin')),
    student_id TEXT,
    password_salt TEXT NOT NULL,
    password_hash TEXT NOT NULL,
    active INTEGER NOT NULL DEFAULT 1,
    FOREIGN KEY(student_id) REFERENCES students(student_id)
);
CREATE TABLE IF NOT EXISTS approval_requests (
    request_id TEXT PRIMARY KEY,
    student_id TEXT NOT NULL REFERENCES students(student_id),
    requested_by TEXT NOT NULL,
    action_type TEXT NOT NULL,
    payload_json TEXT NOT NULL,
    status TEXT NOT NULL CHECK(status IN ('pending','approved','rejected','executed','failed')),
    reviewed_by TEXT,
    review_note TEXT,
    created_at TEXT NOT NULL,
    reviewed_at TEXT,
    executed_at TEXT
);
CREATE TABLE IF NOT EXISTS audit_log (
    audit_id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp TEXT NOT NULL,
    actor TEXT NOT NULL,
    role TEXT NOT NULL,
    action TEXT NOT NULL,
    target TEXT,
    decision TEXT NOT NULL,
    result TEXT NOT NULL,
    details_json TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_approval_status ON approval_requests(status, created_at);
CREATE INDEX IF NOT EXISTS idx_audit_timestamp ON audit_log(timestamp);
