"""Create the SQLite database and insert synthetic sample data (idempotent).

Usage:
    python -m database.init_db            # create + seed (safe to re-run)
    python -m database.init_db --reset    # delete the DB file first
"""
from __future__ import annotations

import argparse
from pathlib import Path

from config import db_path
from database.db import connect, init_schema
from database.seed_data import seed


def init_database(path: str | Path | None = None, with_seed: bool = True) -> dict[str, int]:
    init_schema(path)
    if not with_seed:
        return {}
    with connect(path) as conn:
        return seed(conn)


def main() -> None:
    parser = argparse.ArgumentParser(description="Initialise the demo SQLite database.")
    parser.add_argument("--reset", action="store_true", help="Delete the existing DB file first.")
    args = parser.parse_args()
    target = db_path()
    if args.reset and target.exists():
        target.unlink()
        print(f"Deleted {target}")
    counts = init_database()
    print(f"Database ready at {target}")
    print("Newly inserted rows (0 means data already existed):", counts)
    print("NOTE: all records are SYNTHETIC demonstration data.")


if __name__ == "__main__":
    main()
