"""SYNTHETIC demonstration data. All people, IDs and amounts are fictional."""
from __future__ import annotations

import sqlite3

STUDENTS = [
    # student_id, full_name, email, program, semester, enrollment_year
    ("STU1001", "Aarav Mehta", "aarav.mehta@example.edu", "B.Tech Computer Engineering", 3, 2025),
    ("STU1002", "Diya Patel", "diya.patel@example.edu", "BCA", 5, 2024),
    ("STU1003", "Rohan Shah", "rohan.shah@example.edu", "B.Com", 1, 2026),
    ("STU1004", "Ananya Joshi", "ananya.joshi@example.edu", "MBA", 3, 2025),
    ("STU1005", "Kabir Desai", "kabir.desai@example.edu", "B.Sc Data Science", 7, 2023),
    ("STU1006", "Meera Trivedi", "meera.trivedi@example.edu", "M.Tech Artificial Intelligence", 1, 2026),
]

# student_id, term, total_fee, paid_amount, due_date
FEES = [
    ("STU1001", "2026-Autumn", 120000, 95000, "2026-11-15"),
    ("STU1002", "2026-Autumn", 60000, 60000, "2026-08-31"),
    ("STU1003", "2026-Autumn", 45000, 0, "2026-10-01"),
    ("STU1004", "2026-Autumn", 150000, 75000, "2027-01-15"),
    ("STU1005", "2026-Autumn", 90000, 90000, "2026-08-31"),
    ("STU1006", "2026-Autumn", 130000, 100000, "2026-12-10"),
]

# student_id, name, status, amount, applied_on, remarks   (STU1003 has NO application)
SCHOLARSHIPS = [
    ("STU1001", "Merit Scholarship", "Under Review", None, "2026-09-10", "Application received; committee review in progress."),
    ("STU1002", "Merit Scholarship", "Approved", 15000, "2026-08-20", "Approved for the 2026-27 academic year."),
    ("STU1004", "Need-Based Aid", "Rejected", None, "2026-09-05", "Income certificate was incomplete. You may appeal within 10 days."),
    ("STU1005", "Merit Scholarship", "Documents Required", None, "2026-09-18", "Please upload the previous-year marksheet."),
    ("STU1006", "Research Fellowship", "Submitted", None, "2026-10-02", "Awaiting initial screening."),
]

# ticket_id, student_id, category, description, status, created_at
TICKETS = [
    ("TKT-20260901-A1B2C3", "STU1002", "technical", "Unable to download my fee receipt from the portal.", "Resolved", "2026-09-01T10:15:00"),
    ("TKT-20260915-D4E5F6", "STU1004", "scholarship", "Need clarification on rejection reason for need-based aid.", "In Progress", "2026-09-15T14:40:00"),
]


def seed(conn: sqlite3.Connection) -> dict[str, int]:
    """Insert sample rows idempotently (INSERT OR IGNORE on unique keys).

    Returns how many rows were newly inserted per table (0 on a re-run).
    """
    inserted = {"students": 0, "fees": 0, "scholarships": 0, "support_requests": 0}

    for row in STUDENTS:
        cur = conn.execute(
            "INSERT OR IGNORE INTO students (student_id, full_name, email, program, semester, enrollment_year)"
            " VALUES (?,?,?,?,?,?)", row)
        inserted["students"] += cur.rowcount
    for row in FEES:
        cur = conn.execute(
            "INSERT OR IGNORE INTO fees (student_id, term, total_fee, paid_amount, due_date) VALUES (?,?,?,?,?)", row)
        inserted["fees"] += cur.rowcount
    for row in SCHOLARSHIPS:
        cur = conn.execute(
            "INSERT OR IGNORE INTO scholarships (student_id, scholarship_name, status, amount, applied_on, remarks)"
            " VALUES (?,?,?,?,?,?)", row)
        inserted["scholarships"] += cur.rowcount
    for row in TICKETS:
        cur = conn.execute(
            "INSERT OR IGNORE INTO support_requests (ticket_id, student_id, category, description, status, created_at)"
            " VALUES (?,?,?,?,?,?)", row)
        inserted["support_requests"] += cur.rowcount
    return inserted
