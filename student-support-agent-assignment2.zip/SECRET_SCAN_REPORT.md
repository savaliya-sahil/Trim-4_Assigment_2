# Secret Scan Report

## Scan scope
All source files in the repository (Python, Markdown, YAML, JSON, configuration), excluding:
- `.env` (git-ignored, placeholder values only)
- `data/student_support.db` (local SQLite database, git-ignored)
- `__pycache__/`, `.pytest_cache/`, `.venv/`, `venv/`, `.git/`
- Binary files (`.pyc`, `.db`, `.sqlite`, `.log`, `.png`, `.jpg`)

## Scan patterns
- Groq API keys (`gsk_...`)
- Secret keys (`sk-...`)
- Google API keys (`AIza...`)
- GitHub tokens (`ghp_...`)
- Hardcoded passwords and secrets (`password = "..."`, `SECRET = "..."`)

## Results

| File | Finding | Disposition |
|------|---------|-------------|
| `tests/test_sensitivity.py` | `gsk_abcdefghijklmnop1234` | **False positive** — test fixture only, clearly fake placeholder key used in unit tests |

## Conclusion
No real credentials, API keys, or secrets were found in source code. All configuration values that could be secret are loaded from environment variables via `.env` (git-ignored) or `.env.example` (placeholder values only).

The real Groq API key that was temporarily added to `.env` during testing has been replaced with the placeholder `your_groq_api_key_here`.
