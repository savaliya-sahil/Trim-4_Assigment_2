"""Rule-based intent classification (fast, deterministic, easy to explain and test).

The intent decides: which tools are offered to the model, whether policy retrieval
is needed, and which memories are relevant. The LLM still chooses the actual tool call.
"""
from __future__ import annotations

import re

POLICY_RE = re.compile(
    r"\b(polic\w*|procedures?|rules?|guidelines?|portal|refunds?|late fees?|instal+ments?|deadlines?|eligib\w*|criteria"
    r"|documents?|renew\w*|how (?:do|can|to|should|does)|what happens|steps?|switch|withdraw\w*|appeal\w*|escalat\w*"
    r"|change (?:my |the )?(?:course|program|programme|elective|subject)s?)\b", re.I)
FEE_RE = re.compile(r"\b(fees?|dues?|balance|outstanding|payment status|tuition|owe|pending (?:amount|payment)|payments?)\b", re.I)
SCHOLAR_RE = re.compile(r"\bscholarships?\b", re.I)
COURSE_CHANGE_RE = re.compile(r"\b(course|program|programme|elective|subject)s?\b", re.I)
RECORD_RE = re.compile(r"\b(my (?:profile|details|record|program|programme|course|email|semester|student id|information|enrol\w*)"
                       r"|who am i|(?:program|programme|course) am i (?:enrolled|in))\b", re.I)
SUPPORT_RE = re.compile(r"\b(create|raise|open|file|submit|log|register|make)\b.{0,30}\b(ticket|support request|support case|complaint)\b"
                        r"|\b(ticket|support request)\b.{0,20}\b(create|raise|open)\b", re.I)
MEMORY_Q_RE = re.compile(r"\b(?:what|which)\b.{0,60}\b(remember|prefer\w*|preference\w*|told you|language|asked you)\b"
                         r"|\bdo you remember\b|what do you know about me", re.I)
PREF_RE = re.compile(r"\b(i prefer|i'd prefer|i would prefer|i'd like (?:you to|replies|answers|short|detailed)|please (?:reply|respond|answer|speak|talk|use|keep)"
                     r"|reply (?:to me )?in|respond in|speak (?:to me )?in|remember that|my preferred|i am interested in|i'm interested in"
                     r"|(?:email|call|sms|whatsapp|message|text) me|contact me (?:by|via|on|through))\b", re.I)
GREETING_RE = re.compile(r"^\s*(hi|hello|hey|good (?:morning|afternoon|evening)|thanks|thank you)\b", re.I)

# Tools offered to the model for each intent (least privilege). 'general_query' gets all read tools + ticket.
TOOLS_FOR_INTENT: dict[str, list[str]] = {
    "fee_status": ["check_fee_status"],
    "scholarship_status": ["check_scholarship_status"],
    "student_record": ["get_student_record"],
    "support_request": ["create_support_request"],
}
RETRIEVAL_INTENTS = {"policy_fee", "policy_scholarship", "policy_course", "policy_general", "general_query"}
TOOL_REQUIRED_INTENTS = {"fee_status", "scholarship_status", "student_record"}


def classify_intent(text: str) -> str:
    if MEMORY_Q_RE.search(text):
        return "memory_query"
    if SUPPORT_RE.search(text):
        return "support_request"
    if PREF_RE.search(text) and not POLICY_RE.search(text):
        return "preference_statement"
    if POLICY_RE.search(text):
        if SCHOLAR_RE.search(text):
            return "policy_scholarship"
        if re.search(r"\b(change|switch|withdraw\w*|elective)\b", text, re.I) and COURSE_CHANGE_RE.search(text):
            return "policy_course"
        if FEE_RE.search(text) or re.search(r"\bportal\b", text, re.I):
            return "policy_fee"
        return "policy_general"
    if SCHOLAR_RE.search(text):
        return "scholarship_status"
    if FEE_RE.search(text):
        return "fee_status"
    if RECORD_RE.search(text):
        return "student_record"
    if GREETING_RE.search(text):
        return "greeting"
    return "general_query"
