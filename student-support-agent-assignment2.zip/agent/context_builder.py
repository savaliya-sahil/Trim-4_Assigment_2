"""Context selection: build the smallest useful prompt for the current question.

Only the following can enter the prompt: the question, the selected student's ID,
retrieved policy chunks (top-k, above threshold), relevant non-sensitive memory,
security notices, and - ONLY for short follow-up questions - the last couple of turns.
The report returned alongside records what was included/excluded (no private values).
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any

from agent.prompts import SYSTEM_PROMPT
from retrieval.retriever import RetrievalResult

MAX_HISTORY_TURNS = 2
_FOLLOW_UP_RE = re.compile(r"\b(it|that|this|those|them|again|also|and what|what about|why|more)\b", re.I)


@dataclass
class ContextReport:
    policy_chunks: list[str] = field(default_factory=list)
    memory_keys: list[str] = field(default_factory=list)
    history_messages: int = 0
    security_notice: bool = False
    retrieval_status: str = "not_needed"
    approx_prompt_chars: int = 0
    excluded: str = ("full handbook; other students' records; unrelated memories; "
                     "unrelated chat history; tool outputs not requested")

    def to_dict(self) -> dict[str, Any]:
        return self.__dict__.copy()


def needs_history(question: str) -> bool:
    """Include prior turns only for short/ambiguous follow-ups."""
    return len(question.split()) <= 6 or bool(_FOLLOW_UP_RE.search(question))


def build_context(question: str, student_id: str, *, retrieval: RetrievalResult | None, retrieval_needed: bool,
                  retrieval_error: str | None, memories: list[dict[str, Any]], history: list[dict[str, str]] | None,
                  memory_saved: list[dict[str, str]], security_categories: list[str]
                  ) -> tuple[list[dict[str, Any]], ContextReport]:
    report = ContextReport()
    parts = [f"[Student scope] You are assisting student_id={student_id} only. Use this ID for tool calls."]

    if memories:
        parts.append("[Relevant memory]\n" + "\n".join(f"- {m['label']}: {m['mem_value']}" for m in memories))
        report.memory_keys = [m["mem_key"] for m in memories]
    if memory_saved:
        parts.append("[Memory update] Just saved: " + ", ".join(f"{s['key']} ({s['action']})" for s in memory_saved))
    if security_categories:
        parts.append("[Security notice] The student's message contained sensitive data (" + ", ".join(security_categories)
                     + "). It was redacted and NOT stored. Remind them never to share secrets.")
        report.security_notice = True

    if retrieval_needed:
        if retrieval_error:
            report.retrieval_status = "failed"
            parts.append(f"[Policy evidence] RETRIEVAL FAILED ({retrieval_error}). Do not answer policy questions from memory; tell the student the handbook search is unavailable.")
        elif retrieval is None or retrieval.empty:
            report.retrieval_status = "no_relevant_chunks"
            parts.append("[Policy evidence] No relevant handbook section was found for this question. Say the handbook does not cover it.")
        else:
            report.retrieval_status = "ok"
            report.policy_chunks = [c.chunk_id for c, _ in retrieval.hits]
            parts.append("[Policy evidence] (fictional demo handbook)\n" + "\n".join(
                f"- Section {c.chunk_id.split('::')[1]} ({c.title}): {c.text}" for c, _ in retrieval.hits))

    messages: list[dict[str, Any]] = [{"role": "system", "content": SYSTEM_PROMPT}]
    if history and needs_history(question):
        recent = [m for m in history if m["role"] in ("user", "assistant")][-MAX_HISTORY_TURNS * 2:]
        messages += [{"role": m["role"], "content": m["content"]} for m in recent]
        report.history_messages = len(recent)

    messages.append({"role": "user", "content": "<context>\n" + "\n\n".join(parts) + "\n</context>\n\nStudent question: " + question})
    report.approx_prompt_chars = sum(len(str(m.get("content", ""))) for m in messages)
    return messages, report
