"""Tool registry: schemas, argument validation, authorisation hook and safe execution.

Assignment 2 hook: ``authorize()`` is the single place to add authentication /
authorisation / approval workflows later without touching the agent loop.
"""
from __future__ import annotations

import json
import logging
import time
from dataclasses import dataclass, field
from typing import Any, Callable

from memory.sensitivity_filter import redact
from security import audit
from tools.common import normalize_student_id
from tools.student_tools import check_fee_status, check_scholarship_status, get_student_record
from tools.support_tools import CATEGORIES, create_support_request

logger = logging.getLogger(__name__)

_STUDENT_ID_PROP = {"type": "string", "description": "Student ID such as STU1001."}


@dataclass(frozen=True)
class ToolDef:
    name: str
    description: str
    parameters: dict[str, Any]
    func: Callable[..., dict[str, Any]]
    writes_data: bool = False


TOOLS: dict[str, ToolDef] = {
    "get_student_record": ToolDef(
        "get_student_record", "Get the student's profile (name, program, semester, enrollment status).",
        {"type": "object", "properties": {"student_id": _STUDENT_ID_PROP}, "required": ["student_id"]},
        get_student_record),
    "check_fee_status": ToolDef(
        "check_fee_status", "Get fee total, amount paid, outstanding balance, due date and payment status.",
        {"type": "object", "properties": {"student_id": _STUDENT_ID_PROP}, "required": ["student_id"]},
        check_fee_status),
    "check_scholarship_status": ToolDef(
        "check_scholarship_status", "Get the student's scholarship application status and details.",
        {"type": "object", "properties": {"student_id": _STUDENT_ID_PROP}, "required": ["student_id"]},
        check_scholarship_status),
    "create_support_request": ToolDef(
        "create_support_request",
        "Create a support ticket. Only call when the student explicitly asks for a ticket AND has described the issue.",
        {"type": "object", "properties": {
            "student_id": _STUDENT_ID_PROP,
            "category": {"type": "string", "enum": list(CATEGORIES)},
            "description": {"type": "string", "description": "What the student needs help with (10-1000 chars)."}},
         "required": ["student_id", "category", "description"]},
        create_support_request, writes_data=True),
}


@dataclass
class ToolContext:
    """Who is acting. Today: the demo-selected student. Assignment 2: the authenticated principal."""
    student_id: str


@dataclass
class ToolResult:
    name: str
    ok: bool
    data: dict[str, Any] | None = None
    error: dict[str, str] | None = None
    duration_ms: float = 0.0
    args: dict[str, Any] = field(default_factory=dict)

    @property
    def error_code(self) -> str | None:
        return self.error["code"] if self.error else None

    def to_llm_payload(self) -> dict[str, Any]:
        return {"ok": self.ok, "data": self.data} if self.ok else {"ok": False, "error": self.error}


def openai_tool_specs(names: list[str]) -> list[dict[str, Any]]:
    return [{"type": "function", "function": {"name": n, "description": TOOLS[n].description,
                                              "parameters": TOOLS[n].parameters}} for n in names if n in TOOLS]


def validate_arguments(schema: dict[str, Any], args: Any) -> str | None:
    """Minimal JSON-schema validation (required, unknown keys, type, enum)."""
    if not isinstance(args, dict):
        return "Arguments must be a JSON object."
    props = schema.get("properties", {})
    for req in schema.get("required", []):
        if req not in args or args[req] in (None, ""):
            return f"Missing required argument: {req}."
    for key, value in args.items():
        if key not in props:
            return f"Unexpected argument: {key}."
        if props[key].get("type") == "string" and not isinstance(value, str):
            return f"Argument '{key}' must be a string."
        if "enum" in props[key] and value not in props[key]["enum"]:
            return f"Argument '{key}' must be one of {props[key]['enum']}."
    return None


def authorize(ctx: ToolContext, tool: ToolDef, args: dict[str, Any]) -> str | None:
    """Return an error message if the call must be blocked.

    Current rule: a tool may only act on the student who is chatting. This keeps data
    scoped today and is the extension point for Assignment 2 (authN/authZ, approvals).
    """
    requested = normalize_student_id(args.get("student_id", ""))
    if requested is not None and requested != normalize_student_id(ctx.student_id):
        audit(ctx.student_id, "student", "tool_call", requested, "denied", "cross_student_access", {"tool": tool.name})
        return "You can only access your own student records."
    return None


def execute_tool(name: str, raw_args: Any, ctx: ToolContext) -> ToolResult:
    """Validate and run one tool call. Never raises."""
    start = time.perf_counter()

    def fail(code: str, message: str, args: dict | None = None) -> ToolResult:
        return ToolResult(name, False, error={"code": code, "message": message},
                          duration_ms=(time.perf_counter() - start) * 1000, args=args or {})

    tool = TOOLS.get(name)
    if tool is None:
        return fail("unknown_tool", f"Tool '{name}' does not exist.")
    args = raw_args
    if isinstance(raw_args, str):
        try:
            args = json.loads(raw_args) if raw_args.strip() else {}
        except json.JSONDecodeError:
            return fail("malformed_arguments", "Tool arguments were not valid JSON.")
    problem = validate_arguments(tool.parameters, args)
    safe_args = {k: redact(v) if isinstance(v, str) else v for k, v in args.items()} if isinstance(args, dict) else {}
    if problem:
        return fail("invalid_arguments", problem, safe_args)
    blocked = authorize(ctx, tool, args)
    if blocked:
        return fail("not_authorized", blocked, safe_args)
    try:
        out = tool.func(**args)
    except Exception:  # defensive: a tool bug must not crash the agent
        logger.exception("Unexpected error in tool %s", name)
        return fail("tool_exception", "The tool failed unexpectedly.", safe_args)
    return ToolResult(name, bool(out.get("ok")), out.get("data"), out.get("error"),
                      (time.perf_counter() - start) * 1000, safe_args)
