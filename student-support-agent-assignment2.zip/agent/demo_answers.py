"""Template answers for DEMO mode and for graceful degradation when the LLM is down.

Everything here is built strictly from tool results / retrieved chunks / saved memory.
"""
from __future__ import annotations

from typing import Any

from memory.memory_manager import MEMORY_LABELS

CAPABILITIES = ("I can help with: **fee status**, **scholarship status**, your **student profile**, "
                "**support tickets**, and **handbook policies** (fees, scholarships, course changes, portal issues).")


def money(v: float) -> str:
    return f"₹{v:,.2f}"


def _tool_error_text(err: dict[str, str]) -> str:
    code = err.get("code")
    return {
        "student_not_found": "I couldn't find a student record for that ID, so I can't share any details. Please check the student ID or contact the support office.",
        "invalid_student_id": "That student ID doesn't look valid (expected a format like STU1234), so I couldn't look anything up.",
        "no_fee_record": "I found your student record but there is no fee record on file for you. I can create a support ticket if you'd like someone to check.",
        "database_error": "The student database is temporarily unavailable, so I can't retrieve that right now. Please try again shortly.",
        "not_authorized": "I can only access your own student records.",
        "description_too_short": "Please describe the issue in a little more detail (at least a short sentence).",
    }.get(code, f"I couldn't complete that request ({err.get('message', 'unknown error')}).")


def _fee(d: dict) -> str:
    lines = [f"**Fee status for {d['term']}: {d['payment_status']}**",
             f"- Total fee: {money(d['total_fee'])}", f"- Paid so far: {money(d['paid_amount'])}",
             f"- Outstanding balance: {money(d['outstanding_balance'])}", f"- Due date: {d['due_date']}"]
    if d["is_overdue"]:
        lines.append("\n⚠️ This payment is **overdue**. Late fees may apply - ask me about the late fee policy.")
    return "\n".join(lines)


def _scholarship(d: dict) -> str:
    if not d["has_application"]:
        return "No scholarship application is on file for you. I can explain how to apply if you'd like."
    out = []
    for a in d["applications"]:
        amt = f" (amount {money(a['amount'])})" if a.get("amount") else ""
        out.append(f"**{a['scholarship_name']}: {a['status']}**{amt}\n- Applied on: {a['applied_on']}\n- Remarks: {a['remarks']}")
    return "\n\n".join(out)


def _record(d: dict) -> str:
    return (f"**{d['full_name']}** ({d['student_id']})\n- Program: {d['program']}\n- Semester: {d['semester']}\n"
            f"- Enrolled since: {d['enrollment_year']}\n- Status: {d['enrollment_status']}\n- Email: {d['email']}")


def _policy(state: dict[str, Any]) -> str:
    r = state.get("retrieval")
    if state.get("retrieval_error"):
        return "I'm sorry - the handbook search is unavailable right now, so I can't answer policy questions reliably. Please try again later."
    if r is None or r.empty:
        return ("I couldn't find anything about that in the student handbook, so I can't give you a policy answer. "
                "I don't want to guess. You can ask me to create a support ticket so staff can help.")
    top = r.hits[0][1]
    chosen = [c for c, s in r.hits if s >= 0.8 * top][:2]
    body = "\n\n".join(f"**Section {c.chunk_id.split('::')[1]} - {c.title}**\n{c.text}" for c in chosen)
    return f"Here is what the (fictional demo) handbook says:\n\n{body}"


def _memory(state: dict[str, Any]) -> str:
    mems = state.get("memories") or []
    if not mems:
        return "I don't have any saved preferences for you yet. Tell me, for example, which language you prefer."
    return "Here is what I remember about you:\n" + "\n".join(f"- {m['label']}: {m['mem_value']}" for m in mems)


def compose_answer(state: dict[str, Any]) -> str:
    intent = state["intent"]
    results = state.get("tool_results") or []
    parts: list[str] = []

    if state.get("security_categories"):
        parts.append("🔒 For your safety I did **not** save or use the sensitive details in your message "
                     "(passwords, OTPs, PINs and keys are never stored). Please never share them in chat.")

    if state.get("ask_ticket_details"):
        parts.append("I can create a support ticket for you. Please describe the issue in a sentence or two "
                     "(for example: *\"Please create a support ticket: my fee receipt is missing\"*).")
    elif results:
        r = results[-1]
        if not r.ok:
            parts.append(_tool_error_text(r.error or {}))
        elif r.name == "check_fee_status":
            parts.append(_fee(r.data))
        elif r.name == "check_scholarship_status":
            parts.append(_scholarship(r.data))
        elif r.name == "get_student_record":
            parts.append(_record(r.data))
        elif r.name == "create_support_request":
            parts.append(f"✅ Your support ticket has been created.\n- **Ticket ID: {r.data['ticket_id']}**\n"
                         f"- Category: {r.data['category']}\n- Status: {r.data['status']}\n- Created: {r.data['created_at']}")
    elif intent in {"policy_fee", "policy_scholarship", "policy_course", "policy_general", "general_query"}:
        parts.append(_policy(state))
    elif intent == "memory_query":
        parts.append(_memory(state))
    elif intent == "preference_statement":
        saved = state.get("memory_saved") or []
        if saved:
            items = ", ".join(MEMORY_LABELS.get(s["key"], s["key"]).lower() for s in saved)
            parts.append(f"Got it - I've saved your {items}. I'll remember it in future sessions.")
        elif not state.get("security_categories"):
            parts.append("Thanks! I only remember a few preferences (language, answer style, contact method, course interest).")
    elif intent in {"greeting", "sensitive_input"} or not parts:
        parts.append("Hello! " + CAPABILITIES if intent == "greeting" else "How can I help you today? " + CAPABILITIES)

    lang = next((m["mem_value"] for m in (state.get("memories") or []) if m["mem_key"] == "preferred_language"), None)
    if lang and lang.lower() != "english" and intent != "memory_query":
        parts.append(f"_Note: your saved language preference is {lang}, but demo mode can only reply in English._")
    return "\n\n".join(parts)
