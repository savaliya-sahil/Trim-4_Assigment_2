"""LLM backends: a real Groq client and a deterministic demo planner.

Both implement ``generate(messages, tool_specs, state) -> LLMResponse`` so the agent
loop is identical in both modes. The demo backend is NOT an LLM and is always labelled so.
"""
from __future__ import annotations

import json
import logging
import re
import uuid
from dataclasses import dataclass, field
from typing import Any

from agent.intent import TOOLS_FOR_INTENT

logger = logging.getLogger(__name__)


class LLMError(Exception):
    """Raised for provider failures. ``user_message`` is safe to show in the UI."""
    def __init__(self, kind: str, user_message: str):
        super().__init__(kind)
        self.kind = kind
        self.user_message = user_message


@dataclass
class ToolCall:
    id: str
    name: str
    arguments: str  # raw JSON string, exactly as produced by the model


@dataclass
class LLMResponse:
    content: str | None = None
    tool_calls: list[ToolCall] = field(default_factory=list)
    input_tokens: int | None = None
    output_tokens: int | None = None


# --------------------------------------------------------------------------- Groq
class GroqLLM:
    def __init__(self, api_key: str, model: str, timeout: float = 30.0):
        from groq import Groq  # imported lazily so demo mode works without the package
        self.model = model
        self.client = Groq(api_key=api_key, timeout=timeout, max_retries=1)

    def generate(self, messages: list[dict[str, Any]], tool_specs: list[dict[str, Any]], state: dict[str, Any]) -> LLMResponse:
        import groq
        kwargs: dict[str, Any] = dict(model=self.model, messages=messages, temperature=0.1, max_tokens=700)
        if tool_specs:
            kwargs.update(tools=tool_specs, tool_choice="auto")
        try:
            resp = self.client.chat.completions.create(**kwargs)
        except groq.RateLimitError as exc:
            raise LLMError("rate_limit", "The AI service is receiving too many requests. Please wait a moment and try again.") from exc
        except groq.AuthenticationError as exc:
            raise LLMError("auth", "The AI service rejected the configured API key. Please check your .env settings.") from exc
        except (groq.APIConnectionError, groq.APITimeoutError) as exc:
            raise LLMError("network", "I couldn't reach the AI service (network problem or timeout). Please try again.") from exc
        except groq.NotFoundError as exc:
            raise LLMError("model_not_found", "The configured AI model is unavailable. Please check GROQ_MODEL in your .env file.") from exc
        except groq.BadRequestError as exc:
            kind = "malformed_tool_call" if "tool" in str(exc).lower() else "bad_request"
            raise LLMError(kind, "The AI model produced an invalid request. Please rephrase and try again.") from exc
        except groq.APIStatusError as exc:
            raise LLMError("api_status", f"The AI service returned an error (HTTP {exc.status_code}). Please try again later.") from exc
        except Exception as exc:  # never leak internals
            logger.exception("Unexpected LLM failure")
            raise LLMError("unexpected", "Something went wrong while contacting the AI service.") from exc

        if not resp.choices:
            return LLMResponse()
        msg = resp.choices[0].message
        calls = [ToolCall(tc.id, tc.function.name, tc.function.arguments or "") for tc in (msg.tool_calls or [])]
        usage = getattr(resp, "usage", None)
        return LLMResponse(msg.content, calls,
                           getattr(usage, "prompt_tokens", None), getattr(usage, "completion_tokens", None))


# --------------------------------------------------------------------------- Demo
_CATEGORY_KEYWORDS = [
    ("fees", r"\b(fee|fees|payment|receipt|refund|instal+ment|due)\b"),
    ("scholarship", r"\bscholarship|fellowship|aid\b"),
    ("course", r"\b(course|class|elective|timetable|syllabus|subject|exam)\b"),
    ("technical", r"\b(login|log in|portal|website|app|error|password reset|download)\b"),
]
_DETAIL_RE = re.compile(r"(?:ticket|request|complaint|case)\s*(?:[:\-\u2013]|about|regarding|for|saying|that|to)\s+(.+)$", re.I | re.S)


def extract_ticket_details(text: str) -> tuple[str, str] | None:
    """Return (category, description) or None when the student has not described the issue."""
    m = _DETAIL_RE.search(text.strip())
    if not m:
        return None
    desc = m.group(1).strip().rstrip(".")
    if len(desc) < 10:
        return None
    category = next((c for c, rx in _CATEGORY_KEYWORDS if re.search(rx, desc, re.I)), "general")
    return category, desc


class DemoLLM:
    """Deterministic planner + template writer. Not an AI model."""

    def generate(self, messages: list[dict[str, Any]], tool_specs: list[dict[str, Any]], state: dict[str, Any]) -> LLMResponse:
        from agent.demo_answers import compose_answer  # local import avoids a cycle
        intent, sid = state["intent"], state["student_id"]
        tools = TOOLS_FOR_INTENT.get(intent)
        if tools and not state["tool_results"]:
            name = tools[0]
            if name == "create_support_request":
                details = extract_ticket_details(state["question"])
                if details is None:  # missing information -> ask, do not call the tool
                    return LLMResponse(content=compose_answer({**state, "ask_ticket_details": True}))
                args = {"student_id": sid, "category": details[0], "description": details[1]}
            else:
                args = {"student_id": sid}
            return LLMResponse(tool_calls=[ToolCall(f"demo_{uuid.uuid4().hex[:8]}", name, json.dumps(args))])
        return LLMResponse(content=compose_answer(state))
