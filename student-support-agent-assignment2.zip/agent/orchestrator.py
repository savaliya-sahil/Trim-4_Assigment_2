"""The agent loop.

Pipeline per question
  1. redact/scan for secrets  -> 2. classify intent -> 3. save non-sensitive preferences
  4. retrieve policy chunks (only if needed) -> 5. fetch relevant memory
  6. build minimal context -> 7. bounded loop: LLM -> validated tool calls -> tool results -> LLM ...
  8. finalise answer + trace (latency, tokens, tools, retrieval, errors).
"""
from __future__ import annotations

import json
import logging
import time
import uuid
from dataclasses import dataclass
from typing import Any

from agent.context_builder import build_context
from agent.demo_answers import compose_answer
from agent.intent import RETRIEVAL_INTENTS, TOOL_REQUIRED_INTENTS, TOOLS_FOR_INTENT, classify_intent
from agent.llm_client import DemoLLM, GroqLLM, LLMError
from agent.prompts import NUDGE_TOOL_REQUIRED
from agent.tool_registry import TOOLS, ToolContext, ToolResult, execute_tool, openai_tool_specs
from config import Settings, load_settings
from memory import memory_manager
from memory.sensitivity_filter import scan_text
from observability.tracing import Trace, record_security_event, save_trace, student_ref
from retrieval.retriever import Retriever, RetrievalResult

logger = logging.getLogger(__name__)
MAX_TOOL_CALLS_PER_TURN = 3


@dataclass
class AgentResponse:
    answer: str
    trace: dict[str, Any]
    success: bool
    mode: str


class StudentSupportAgent:
    def __init__(self, settings: Settings | None = None, retriever: Retriever | None = None,
                 retriever_error: str | None = None, llm: Any | None = None):
        self.settings = settings or load_settings()
        self.retriever = retriever
        self.retriever_error = retriever_error
        self.llm = llm or self._make_llm()

    def _make_llm(self) -> Any:
        if self.settings.use_llm:
            try:
                return GroqLLM(self.settings.groq_api_key, self.settings.groq_model, self.settings.request_timeout)
            except Exception:
                logger.exception("Could not initialise the Groq client; falling back to demo mode")
        return DemoLLM()

    @property
    def mode(self) -> str:
        return "groq" if isinstance(self.llm, GroqLLM) else "demo"

    @property
    def model_label(self) -> str:
        return self.settings.groq_model if self.mode == "groq" else "demo-mode (no LLM)"

    # ------------------------------------------------------------------ public API
    def handle(self, question: str, student_id: str, session_id: str | None = None,
               history: list[dict[str, str]] | None = None) -> AgentResponse:
        start = time.perf_counter()
        scan = scan_text(question or "")
        trace = Trace(student_ref=student_ref(student_id), session_id=session_id, question_redacted=scan.redacted_text,
                      model=self.model_label, mode=self.mode)
        try:
            answer = self._run(question or "", scan, student_id, history, trace)
        except Exception as exc:  # last-resort guard: never leak a stack trace to the UI
            logger.exception("Unhandled agent error")
            trace.errors.append(f"unexpected_error:{type(exc).__name__}")
            trace.success = False
            answer = "Sorry, something went wrong on my side while handling that. Please try again."
        trace.latency_ms = round((time.perf_counter() - start) * 1000, 2)
        try:
            data = save_trace(trace)
        except Exception:
            logger.exception("Could not persist trace")
            data = trace.to_dict()
        return AgentResponse(answer, data, trace.success, self.mode)

    # ------------------------------------------------------------------ internals
    def _run(self, question: str, scan, student_id: str, history, trace: Trace) -> str:
        safe_q = scan.redacted_text.strip()
        if not safe_q:
            trace.intent, trace.success = "empty_input", True
            return "Please type a question and I'll do my best to help."

        # 1-2. security + intent
        intent = classify_intent(safe_q)
        if scan.is_sensitive:
            trace.flags.append("sensitive_input_redacted")
            trace.errors.append("sensitive_content_detected:" + ",".join(scan.categories))
            record_security_event(student_id, "sensitive_input_blocked", scan.categories, trace.trace_id)
            if intent in {"general_query", "preference_statement"}:
                intent = "sensitive_input"
        trace.intent = intent

        # 3. persistent memory write (skipped automatically for sensitive messages)
        memory_saved: list[dict[str, str]] = []
        memories: list[dict[str, Any]] = []
        try:
            if intent != "memory_query":
                outcome = memory_manager.save_preferences(student_id, safe_q if not scan.is_sensitive else question)
                memory_saved = outcome.saved
                trace.memory_saved = [f"{s['key']}:{s['action']}" for s in memory_saved]
            # 5. relevant memory
            memories = memory_manager.get_relevant_memories(student_id, intent)
            trace.memory_refs = [f"mem:{m['mem_key']}" for m in memories]
        except Exception:
            logger.exception("Memory operation failed")
            trace.errors.append("memory_error")

        # 4. retrieval (only for policy-type questions)
        retrieval: RetrievalResult | None = None
        retrieval_error: str | None = None
        retrieval_needed = intent in RETRIEVAL_INTENTS
        if retrieval_needed:
            trace.retrieval_used = True
            if self.retriever is None:
                retrieval_error = self.retriever_error or "retriever not initialised"
                trace.errors.append("retrieval_unavailable")
            else:
                try:
                    retrieval = self.retriever.search(safe_q, self.settings.retrieval_top_k)
                    trace.retrieval_backend = retrieval.backend
                    trace.retrieved_chunks = [{"id": c.chunk_id, "score": round(s, 3)} for c, s in retrieval.hits]
                    if retrieval.empty:
                        trace.flags.append("retrieval_empty")
                except Exception as exc:
                    logger.exception("Retrieval failed")
                    retrieval_error = type(exc).__name__
                    trace.errors.append("retrieval_error")

        # 6. context selection
        messages, report = build_context(
            safe_q, student_id, retrieval=retrieval, retrieval_needed=retrieval_needed, retrieval_error=retrieval_error,
            memories=memories, history=history, memory_saved=memory_saved, security_categories=scan.categories)
        trace.context_report = report.to_dict()

        tool_names = list(TOOLS) if intent == "general_query" else TOOLS_FOR_INTENT.get(intent, [])
        tool_specs = openai_tool_specs(tool_names)
        tool_results: list[ToolResult] = []
        state = {"intent": intent, "question": safe_q, "student_id": student_id, "tool_results": tool_results,
                 "retrieval": retrieval, "retrieval_error": retrieval_error, "memories": memories,
                 "memory_saved": memory_saved, "security_categories": scan.categories}

        # 7. bounded agent loop
        ctx = ToolContext(student_id=student_id)
        seen_calls: set[str] = set()
        in_tok = out_tok = 0
        have_usage = False
        empty_retries = nudges = 0
        final: str | None = None

        for i in range(self.settings.max_iterations):
            trace.iterations = i + 1
            try:
                resp = self.llm.generate(messages, tool_specs, state)
            except LLMError as exc:
                trace.errors.append(f"llm_error:{exc.kind}")
                self._set_usage(trace, have_usage, in_tok, out_tok)
                return self._degraded(state, trace, exc.user_message)
            if resp.input_tokens is not None or resp.output_tokens is not None:
                have_usage = True
                in_tok += resp.input_tokens or 0
                out_tok += resp.output_tokens or 0

            if resp.tool_calls:
                messages.append({"role": "assistant", "content": resp.content or "", "tool_calls": [
                    {"id": c.id, "type": "function", "function": {"name": c.name, "arguments": c.arguments or "{}"}}
                    for c in resp.tool_calls[:MAX_TOOL_CALLS_PER_TURN]]})
                for call in resp.tool_calls[:MAX_TOOL_CALLS_PER_TURN]:
                    signature = f"{call.name}:{call.arguments}"
                    if call.name not in tool_names:
                        result = ToolResult(call.name, False, error={"code": "tool_not_allowed",
                                            "message": "This tool is not available for this question."})
                    elif signature in seen_calls:
                        result = ToolResult(call.name, False, error={"code": "duplicate_call",
                                            "message": "This exact call was already made; use the earlier result."})
                    else:
                        seen_calls.add(signature)
                        result = execute_tool(call.name, call.arguments, ctx)
                    tool_results.append(result)
                    trace.add_tool(result.name, result.ok, result.duration_ms, result.error_code, result.args)
                    if not result.ok:
                        trace.errors.append(f"tool_error:{result.name}:{result.error_code}")
                    messages.append({"role": "tool", "tool_call_id": call.id,
                                     "content": json.dumps(result.to_llm_payload(), default=str)})
                continue

            if resp.content and resp.content.strip():
                if intent in TOOL_REQUIRED_INTENTS and not tool_results and nudges < 1 and tool_specs:
                    nudges += 1  # the model tried to answer student data without a tool
                    trace.flags.append("tool_required_nudge")
                    messages.append({"role": "assistant", "content": resp.content})
                    messages.append({"role": "user", "content": NUDGE_TOOL_REQUIRED})
                    continue
                final = resp.content.strip()
                break
            empty_retries += 1  # empty / malformed model output
            trace.flags.append("empty_model_response")
            if empty_retries > 1:
                trace.errors.append("llm_error:empty_response")
                self._set_usage(trace, have_usage, in_tok, out_tok)
                return self._degraded(state, trace, "The AI model returned an empty response.")
        else:
            trace.errors.append("max_iterations_reached")

        self._set_usage(trace, have_usage, in_tok, out_tok)

        if final is None:
            trace.success = False
            return "I wasn't able to finish that request. Please try rephrasing your question."
        trace.success = True
        return final

    @staticmethod
    def _set_usage(trace: Trace, have_usage: bool, in_tok: int, out_tok: int) -> None:
        """Only API-reported usage is recorded; otherwise tokens stay 'unavailable'."""
        if have_usage:
            trace.input_tokens, trace.output_tokens, trace.token_source = in_tok, out_tok, "api"

    def _degraded(self, state: dict[str, Any], trace: Trace, reason: str) -> str:
        """LLM unavailable: show only verified data we already hold, clearly labelled. Never invent."""
        trace.success = False
        trace.degraded = True
        if state["tool_results"] or (state["intent"] in RETRIEVAL_INTENTS and state["retrieval"] is not None):
            return f"⚠️ {reason} Here is the verified information I already retrieved:\n\n" + compose_answer(state)
        return f"⚠️ {reason}"
