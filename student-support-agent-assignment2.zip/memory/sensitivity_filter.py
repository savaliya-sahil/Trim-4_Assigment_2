"""Basic sensitivity filter: detect and redact secrets BEFORE anything is stored.

It is intentionally simple (regex based) and documented as best-effort: it catches
passwords, OTPs, PINs, API keys/tokens, card numbers and Aadhaar-style numbers.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field

# (category, compiled pattern). Order matters: specific key formats first.
_PATTERNS: list[tuple[str, re.Pattern[str]]] = [
    ("api_key", re.compile(r"\b(?:gsk_[A-Za-z0-9]{10,}|sk-[A-Za-z0-9_\-]{10,}|AIza[0-9A-Za-z_\-]{20,}|ghp_[A-Za-z0-9]{20,})\b")),
    ("api_key", re.compile(r"(?i)\bapi[ _-]?key\b\s*(?:is|was|=|:)\s*\S+")),
    ("token", re.compile(r"(?i)\b(?:bearer|access[ _-]?token|auth(?:entication)?[ _-]?token|secret)\b\s*(?:is|was|=|:)?\s*[A-Za-z0-9._\-]{12,}")),
    ("otp", re.compile(r"(?i)\b(?:otp|one[- ]time (?:password|code|pin)|verification code)\b\s*(?:is|was|=|:)?\s*\d{4,8}\b")),
    ("otp", re.compile(r"(?i)\b\d{4,8}\b\s*(?:is|was)\s*(?:my|the)\s*(?:otp|one[- ]time (?:password|code)|verification code)")),
    ("password", re.compile(r"(?i)\b(?:password|passwd|pwd|passcode|pin)\b\s*(?:is|was|=|:)\s*\S+")),
    ("secret_storage_request", re.compile(r"(?i)\b(?:remember|save|store|keep)\b[^.?!\n]{0,30}\b(?:password|passwd|otp|pin|passcode|api key|token)\b")),
    ("card_number", re.compile(r"\b(?:\d[ -]?){13,16}\b")),
    ("national_id", re.compile(r"\b\d{4}\s\d{4}\s\d{4}\b|\b\d{12}\b")),
]


@dataclass
class ScanResult:
    is_sensitive: bool
    categories: list[str] = field(default_factory=list)
    redacted_text: str = ""


def scan_text(text: str) -> ScanResult:
    """Return whether ``text`` contains secrets, which categories, and a redacted copy."""
    redacted = text or ""
    categories: list[str] = []
    for category, pattern in _PATTERNS:
        if pattern.search(redacted):
            redacted = pattern.sub(f"[REDACTED:{category}]", redacted)
            if category not in categories:
                categories.append(category)
    return ScanResult(bool(categories), categories, redacted)


def redact(text: str) -> str:
    return scan_text(text).redacted_text
