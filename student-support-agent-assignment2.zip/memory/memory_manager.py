"""Persistent, non-sensitive memory stored in SQLite (table ``student_memories``).

* Only four low-risk kinds of preference are ever stored (see ``MEMORY_LABELS``).
* Text is scanned by the sensitivity filter first; if anything sensitive is found,
  NOTHING from that message is saved and only a safe diagnostic event is logged.
* One row per (student, key): saving again UPDATES the value (deduplication).
* Retrieval is relevance-gated per intent (``RELEVANT_INTENTS``).
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any

from database.db import connect
from memory.sensitivity_filter import scan_text
from observability.tracing import now_iso

MEMORY_LABELS = {
    "preferred_language": "Preferred language",
    "communication_style": "Preferred answer style",
    "contact_preference": "Preferred contact method",
    "course_interest": "Course / subject interest",
}

# Which memories matter for which question types. "*" = every answer (e.g. language).
RELEVANT_INTENTS: dict[str, set[str] | str] = {
    "preferred_language": "*",
    "communication_style": "*",
    "contact_preference": {"support_request", "memory_query"},
    "course_interest": {"policy_course", "general_query", "student_record", "scholarship_status", "memory_query"},
}

_LANGS = "hindi|gujarati|english|marathi|tamil|telugu|bengali|urdu|kannada|punjabi"
_LANG_RE = re.compile(rf"\b({_LANGS})\b", re.I)
_LANG_TRIGGER = re.compile(r"(?i)\b(prefer|reply|respond|answer|speak|talk|write|language|communicate|use)\b")
_STYLE_RE = re.compile(r"(?i)\b(short|brief|concise|detailed|step[- ]by[- ]step|simple)\b[^.?!]{0,40}\b(answers?|repl(?:y|ies)|responses?|explanations?|language)\b"
                       r"|\b(answers?|repl(?:y|ies)|responses?|explanations?)\b[^.?!]{0,25}\b(short|brief|concise|detailed|step[- ]by[- ]step|simple)\b")
_STYLE_WORD = re.compile(r"(?i)\b(short|brief|concise|detailed|step[- ]by[- ]step|simple)\b")
_CONTACT_RE = re.compile(r"(?i)\b(email|e-mail|call|sms|whatsapp|text|message)\s+me\b|\bcontact me (?:by|via|on|through)\s+(email|phone|sms|whatsapp)\b")
_INTEREST_RE = re.compile(r"(?i)\b(?:i am|i'm|i’m)\s+interested in\s+([A-Za-z][A-Za-z &/+\-]{2,50})")


@dataclass
class SaveOutcome:
    saved: list[dict[str, str]] = field(default_factory=list)   # [{"key":..., "action": created|updated|unchanged}]
    blocked: bool = False
    categories: list[str] = field(default_factory=list)


def extract_preferences(text: str) -> list[tuple[str, str]]:
    """Rule-based extraction of storable preferences from a (already redacted) message."""
    found: dict[str, str] = {}
    if (m := _LANG_RE.search(text)) and _LANG_TRIGGER.search(text):
        found["preferred_language"] = m.group(1).title()
    if _STYLE_RE.search(text) and (m := _STYLE_WORD.search(text)):
        found["communication_style"] = m.group(1).lower().replace("-", " ")
    if (m := _CONTACT_RE.search(text)):
        word = (m.group(1) or m.group(2) or "").lower()
        found["contact_preference"] = {"text": "sms", "message": "sms", "e-mail": "email"}.get(word, word)
    if (m := _INTEREST_RE.search(text)):
        found["course_interest"] = m.group(1).strip(" .,-").title()
    return list(found.items())


def _student_exists(conn, student_id: str) -> bool:
    return conn.execute("SELECT 1 FROM students WHERE student_id = ?", (student_id,)).fetchone() is not None


def save_preferences(student_id: str, text: str) -> SaveOutcome:
    """Scan, extract and upsert preferences. Never stores anything from sensitive messages."""
    scan = scan_text(text)
    if scan.is_sensitive:
        return SaveOutcome(blocked=True, categories=scan.categories)
    prefs = extract_preferences(text)
    outcome = SaveOutcome()
    if not prefs:
        return outcome
    now = now_iso()
    with connect() as conn:
        if not _student_exists(conn, student_id):
            return outcome
        for key, value in prefs:
            row = conn.execute("SELECT mem_value FROM student_memories WHERE student_id=? AND mem_key=?",
                               (student_id, key)).fetchone()
            if row is None:
                conn.execute("INSERT INTO student_memories (student_id, mem_key, mem_value, created_at, updated_at)"
                             " VALUES (?,?,?,?,?)", (student_id, key, value, now, now))
                action = "created"
            elif row["mem_value"] != value:
                conn.execute("UPDATE student_memories SET mem_value=?, updated_at=? WHERE student_id=? AND mem_key=?",
                             (value, now, student_id, key))
                action = "updated"
            else:
                action = "unchanged"
            outcome.saved.append({"key": key, "action": action})
    return outcome


def list_memories(student_id: str) -> list[dict[str, Any]]:
    with connect() as conn:
        rows = conn.execute("SELECT mem_key, mem_value, updated_at FROM student_memories WHERE student_id=?"
                            " ORDER BY mem_key", (student_id,)).fetchall()
    return [dict(r) | {"label": MEMORY_LABELS.get(r["mem_key"], r["mem_key"])} for r in rows]


def get_relevant_memories(student_id: str, intent: str) -> list[dict[str, Any]]:
    """Return only the memories that matter for this kind of question."""
    selected = []
    for m in list_memories(student_id):
        rule = RELEVANT_INTENTS.get(m["mem_key"], set())
        if intent == "memory_query" or rule == "*" or intent in rule:
            selected.append(m)
    return selected


def clear_memories(student_id: str) -> int:
    with connect() as conn:
        return conn.execute("DELETE FROM student_memories WHERE student_id=?", (student_id,)).rowcount
