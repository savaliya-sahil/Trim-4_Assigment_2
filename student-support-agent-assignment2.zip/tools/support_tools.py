"""Write tool: create a support ticket in SQLite."""
from __future__ import annotations

import sqlite3
import uuid
from datetime import datetime, timezone
from typing import Any

from database.db import connect
from memory.sensitivity_filter import redact
from tools.common import err, normalize_student_id, ok, safe_db

CATEGORIES = ("fees", "scholarship", "course", "technical", "general")
MIN_DESC, MAX_DESC = 10, 1000


@safe_db
def create_support_request(student_id: str, category: str, description: str) -> dict[str, Any]:
    sid = normalize_student_id(student_id)
    if not sid:
        return err("invalid_student_id", "Student ID must look like STU1234.")
    cat = (category or "").strip().lower()
    if cat not in CATEGORIES:
        return err("invalid_category", f"Category must be one of: {', '.join(CATEGORIES)}.")
    desc = redact((description or "").strip())  # defence in depth: never store secrets in tickets
    if len(desc) < MIN_DESC:
        return err("description_too_short", f"Please describe the issue in at least {MIN_DESC} characters.")
    if len(desc) > MAX_DESC:
        return err("description_too_long", f"Description must be at most {MAX_DESC} characters.")

    created_at = datetime.now(timezone.utc).isoformat(timespec="seconds")
    with connect() as conn:
        if conn.execute("SELECT 1 FROM students WHERE student_id = ?", (sid,)).fetchone() is None:
            return err("student_not_found", f"No student record exists for ID {sid}.")
        for _ in range(5):  # retry on the (very unlikely) ID collision
            ticket_id = f"TKT-{datetime.now(timezone.utc):%Y%m%d}-{uuid.uuid4().hex[:6].upper()}"
            try:
                conn.execute(
                    "INSERT INTO support_requests (ticket_id, student_id, category, description, status, created_at)"
                    " VALUES (?,?,?,?,?,?)", (ticket_id, sid, cat, desc, "Open", created_at))
                return ok({"ticket_id": ticket_id, "student_id": sid, "category": cat,
                           "description": desc, "status": "Open", "created_at": created_at})
            except sqlite3.IntegrityError:
                continue
    return err("ticket_id_generation_failed", "Could not generate a unique ticket ID. Please try again.")
