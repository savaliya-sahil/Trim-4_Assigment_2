"""Shared helpers for tool functions."""
from __future__ import annotations

import functools
import logging
import re
import sqlite3
from typing import Any, Callable

logger = logging.getLogger(__name__)

STUDENT_ID_RE = re.compile(r"^STU\d{4}$")


def ok(data: dict[str, Any]) -> dict[str, Any]:
    return {"ok": True, "data": data}


def err(code: str, message: str) -> dict[str, Any]:
    return {"ok": False, "error": {"code": code, "message": message}}


def normalize_student_id(value: Any) -> str | None:
    """Return a canonical ID (e.g. ``stu1001`` -> ``STU1001``) or None if invalid."""
    if not isinstance(value, str):
        return None
    candidate = value.strip().upper()
    return candidate if STUDENT_ID_RE.match(candidate) else None


def safe_db(func: Callable[..., dict[str, Any]]) -> Callable[..., dict[str, Any]]:
    """Convert database exceptions into a structured error (details go to logs only)."""
    @functools.wraps(func)
    def wrapper(*args: Any, **kwargs: Any) -> dict[str, Any]:
        try:
            return func(*args, **kwargs)
        except sqlite3.Error:
            logger.exception("Database error in tool %s", func.__name__)
            return err("database_error", "The student database is temporarily unavailable. Please try again later.")
    return wrapper
