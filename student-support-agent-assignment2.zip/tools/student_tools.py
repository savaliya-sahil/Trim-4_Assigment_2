"""Read-only student tools: profile, fee status, scholarship status.

Every tool returns ``{"ok": True, "data": {...}}`` or
``{"ok": False, "error": {"code": ..., "message": ...}}`` and never invents data.
"""
from __future__ import annotations

from datetime import date
from typing import Any

from database.db import connect
from tools.common import err, normalize_student_id, ok, safe_db


def _invalid_id() -> dict[str, Any]:
    return err("invalid_student_id", "Student ID must look like STU1234.")


@safe_db
def get_student_record(student_id: str) -> dict[str, Any]:
    sid = normalize_student_id(student_id)
    if not sid:
        return _invalid_id()
    with connect() as conn:
        row = conn.execute(
            "SELECT student_id, full_name, email, program, semester, enrollment_year, enrollment_status"
            " FROM students WHERE student_id = ?", (sid,)).fetchone()
    if row is None:
        return err("student_not_found", f"No student record exists for ID {sid}.")
    return ok(dict(row))


@safe_db
def check_fee_status(student_id: str) -> dict[str, Any]:
    sid = normalize_student_id(student_id)
    if not sid:
        return _invalid_id()
    with connect() as conn:
        student = conn.execute("SELECT 1 FROM students WHERE student_id = ?", (sid,)).fetchone()
        if student is None:
            return err("student_not_found", f"No student record exists for ID {sid}.")
        row = conn.execute(
            "SELECT term, total_fee, paid_amount, due_date FROM fees WHERE student_id = ?"
            " ORDER BY due_date DESC LIMIT 1", (sid,)).fetchone()
    if row is None:
        return err("no_fee_record", f"No fee record is available for {sid}.")
    total, paid = float(row["total_fee"]), float(row["paid_amount"])
    outstanding = round(max(total - paid, 0.0), 2)  # balance is calculated, not stored
    if outstanding == 0:
        status = "Paid"
    elif paid == 0:
        status = "Unpaid"
    else:
        status = "Partially Paid"
    overdue = outstanding > 0 and row["due_date"] < date.today().isoformat()
    return ok({
        "student_id": sid, "term": row["term"], "currency": "INR",
        "total_fee": total, "paid_amount": paid, "outstanding_balance": outstanding,
        "payment_status": status, "due_date": row["due_date"], "is_overdue": overdue,
    })


@safe_db
def check_scholarship_status(student_id: str) -> dict[str, Any]:
    sid = normalize_student_id(student_id)
    if not sid:
        return _invalid_id()
    with connect() as conn:
        student = conn.execute("SELECT 1 FROM students WHERE student_id = ?", (sid,)).fetchone()
        if student is None:
            return err("student_not_found", f"No student record exists for ID {sid}.")
        rows = conn.execute(
            "SELECT scholarship_name, status, amount, applied_on, remarks FROM scholarships"
            " WHERE student_id = ? ORDER BY applied_on DESC", (sid,)).fetchall()
    if not rows:
        return ok({"student_id": sid, "has_application": False, "applications": [],
                   "message": "No scholarship application is on file for this student."})
    return ok({"student_id": sid, "has_application": True, "applications": [dict(r) for r in rows]})
