"""Centralised configuration for the Intelligent Student Support Agent.

All secrets and tunables come from environment variables (a local ``.env`` file
is loaded automatically). Nothing secret is ever hard-coded or printed.
"""
from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent
load_dotenv(BASE_DIR / ".env")

POLICY_PATH = BASE_DIR / "data" / "student_policy.md"
SCHEMA_PATH = BASE_DIR / "database" / "schema.sql"

_PLACEHOLDER_KEYS = {"", "your_groq_api_key_here", "changeme", "xxx"}


def db_path() -> Path:
    """SQLite file location. Read at call time so tests/evaluation can override it."""
    return Path(os.getenv("STUDENT_DB_PATH", str(BASE_DIR / "data" / "student_support.db")))


def _as_bool(value: str | None) -> bool:
    return str(value or "").strip().lower() in {"1", "true", "yes", "on"}


@dataclass(frozen=True)
class Settings:
    groq_api_key: str
    groq_model: str
    demo_mode: bool
    max_iterations: int
    request_timeout: float
    retrieval_top_k: int
    embedding_backend: str  # auto | sentence-transformers | tfidf
    log_level: str

    @property
    def use_llm(self) -> bool:
        """True only when a real key is configured and demo mode is not forced."""
        return bool(self.groq_api_key) and not self.demo_mode

    @property
    def mode(self) -> str:
        return "groq" if self.use_llm else "demo"

    @property
    def model_label(self) -> str:
        return self.groq_model if self.use_llm else "demo-mode (no LLM)"


def load_settings() -> Settings:
    key = os.getenv("GROQ_API_KEY", "").strip()
    if key.lower() in _PLACEHOLDER_KEYS:
        key = ""
    return Settings(
        groq_api_key=key,
        # Model names change over time on Groq - keep this configurable.
        groq_model=os.getenv("GROQ_MODEL", "llama-3.3-70b-versatile").strip(),
        demo_mode=_as_bool(os.getenv("DEMO_MODE")),
        max_iterations=max(1, int(os.getenv("MAX_AGENT_ITERATIONS", "4"))),
        request_timeout=float(os.getenv("LLM_TIMEOUT_SECONDS", "30")),
        retrieval_top_k=max(1, int(os.getenv("RETRIEVAL_TOP_K", "3"))),
        embedding_backend=os.getenv("EMBEDDING_BACKEND", "auto").strip().lower(),
        log_level=os.getenv("LOG_LEVEL", "INFO").upper(),
    )
