"""Structured tracing. Traces are stored in SQLite (``traces`` table), redacted first."""
from __future__ import annotations

import hashlib
import json
import uuid
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from typing import Any

from database.db import connect
from memory.sensitivity_filter import redact


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def student_ref(student_id: str | None) -> str:
    """Pseudonymous reference so traces never contain the raw student ID."""
    if not student_id:
        return "anon-unknown"
    return "anon-" + hashlib.sha256(student_id.encode()).hexdigest()[:8]


@dataclass
class Trace:
    trace_id: str = field(default_factory=lambda: uuid.uuid4().hex[:12])
    timestamp: str = field(default_factory=now_iso)
    student_ref: str = "anon-unknown"
    session_id: str | None = None
    question_redacted: str = ""
    intent: str | None = None
    tools: list[dict[str, Any]] = field(default_factory=list)  # name,status,duration_ms,error_code,args
    retrieval_used: bool = False
    retrieval_backend: str | None = None
    retrieved_chunks: list[dict[str, Any]] = field(default_factory=list)  # id, score
    memory_refs: list[str] = field(default_factory=list)
    memory_saved: list[str] = field(default_factory=list)
    context_report: dict[str, Any] = field(default_factory=dict)
    flags: list[str] = field(default_factory=list)
    iterations: int = 0
    success: bool = False
    degraded: bool = False
    latency_ms: float | None = None
    model: str = ""
    mode: str = "demo"
    input_tokens: int | None = None
    output_tokens: int | None = None
    token_source: str = "unavailable"  # "api" when reported by the provider, else "unavailable"
    errors: list[str] = field(default_factory=list)

    def add_tool(self, name: str, ok: bool, duration_ms: float, error_code: str | None, args: dict) -> None:
        masked = {k: (self.student_ref if k == "student_id" else v) for k, v in args.items()}  # keep IDs out of traces
        self.tools.append({"name": name, "status": "success" if ok else "error",
                           "duration_ms": round(duration_ms, 2), "error_code": error_code, "args": masked})

    def to_dict(self) -> dict[str, Any]:
        return _redact_obj(asdict(self))


def _redact_obj(obj: Any) -> Any:
    if isinstance(obj, str):
        return redact(obj)
    if isinstance(obj, list):
        return [_redact_obj(x) for x in obj]
    if isinstance(obj, dict):
        return {k: _redact_obj(v) for k, v in obj.items()}
    return obj


def save_trace(trace: Trace) -> dict[str, Any]:
    data = trace.to_dict()
    with connect() as conn:
        conn.execute(
            "INSERT OR REPLACE INTO traces (trace_id, created_at, student_ref, intent, success, latency_ms,"
            " model, input_tokens, output_tokens, trace_json) VALUES (?,?,?,?,?,?,?,?,?,?)",
            (data["trace_id"], data["timestamp"], data["student_ref"], data["intent"], int(data["success"]),
             data["latency_ms"], data["model"], data["input_tokens"], data["output_tokens"], json.dumps(data)),
        )
    return data


def list_traces(limit: int = 50) -> list[dict[str, Any]]:
    with connect() as conn:
        rows = conn.execute("SELECT trace_json FROM traces ORDER BY created_at DESC, rowid DESC LIMIT ?", (limit,)).fetchall()
    return [json.loads(r["trace_json"]) for r in rows]


def record_security_event(student_id: str | None, event_type: str, categories: list[str], trace_id: str | None) -> None:
    """Store a safe diagnostic: WHAT kind of secret was seen, never its value."""
    with connect() as conn:
        conn.execute(
            "INSERT INTO security_events (created_at, student_ref, event_type, categories, trace_id) VALUES (?,?,?,?,?)",
            (now_iso(), student_ref(student_id), event_type, ",".join(categories), trace_id),
        )
