"""Aggregate metrics over trace dictionaries (used by the UI and the evaluation script)."""
from __future__ import annotations

import statistics
from typing import Any, Iterable


def summarize_traces(traces: Iterable[dict[str, Any]]) -> dict[str, Any]:
    traces = list(traces)
    n = len(traces)
    latencies = [t["latency_ms"] for t in traces if t.get("latency_ms") is not None]
    api_in = [t["input_tokens"] for t in traces if t.get("token_source") == "api" and t.get("input_tokens") is not None]
    api_out = [t["output_tokens"] for t in traces if t.get("token_source") == "api" and t.get("output_tokens") is not None]
    tool_calls = [c for t in traces for c in t.get("tools", [])]
    ok_tools = [c for c in tool_calls if c["status"] == "success"]
    return {
        "requests": n,
        "completion_rate": round(sum(1 for t in traces if t.get("success")) / n, 4) if n else None,
        "avg_latency_ms": round(statistics.mean(latencies), 2) if latencies else None,
        "median_latency_ms": round(statistics.median(latencies), 2) if latencies else None,
        "tool_calls": len(tool_calls),
        "tool_success_rate": round(len(ok_tools) / len(tool_calls), 4) if tool_calls else None,
        "total_input_tokens_api": sum(api_in) if api_in else "unavailable",
        "total_output_tokens_api": sum(api_out) if api_out else "unavailable",
        "token_note": "Token counts are API-reported only; 'unavailable' means no API usage data (e.g. demo mode).",
    }
