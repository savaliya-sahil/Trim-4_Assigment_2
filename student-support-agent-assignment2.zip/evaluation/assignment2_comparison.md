# Assignment 2 Final Evaluation and Assignment 1 Comparison

## Measurement conditions

- Assignment 1 baseline values below come from `report.md`, generated in deterministic demo mode with no LLM API call.
- Assignment 2 security workflow was tested locally against fresh SQLite databases using pytest.
- Do not describe deterministic/demo results as real-world LLM accuracy. Live Groq token counts require running with a valid API key and recording actual API usage.

## Test results

| Test suite | Assignment 1 baseline | Assignment 2 after changes | Notes |
|------------|----------------------|---------------------------|-------|
| Unit tests (`pytest -q`) | 48/48 passed (100%) | 48/48 passed | All original Assignment 1 regression tests continue to pass |
| Assignment 2 security tests | N/A | 27/27 passed | New tests for auth, authorization, approval, audit, memory privacy |
| Total unit tests | 48 | 75 | 48 original + 27 new Assignment 2 tests |

## Side-by-side comparison

| Metric | Assignment 1 baseline | Assignment 2 verification | Interpretation |
|--------|----------------------|---------------------------|----------------|
| Existing Assignment 1 evaluation cases | 17/17 passed (100%) | Existing evaluation remains available; run again after any changes | Core support, memory, retrieval and tracing cases remain covered |
| Unit tests | 48/48 passed before Assignment 2 changes | 75/75 passed after Assignment 2 changes | 27 new security workflow tests added |
| Own-record fee/scholarship | Supported in baseline | Authorization still scopes tools to authenticated student ID | Allowed when student signs in and requests their own record |
| Cross-student private-record attempt | Basic tool authorization hook existed | Tool authorization + authenticated identity integration | Blocked when requested student ID differs from signed-in identity |
| Sensitive change workflow | Not present | Request remains pending until administrator decision | No automatic execution on student request |
| Approval rejection | Not present | Tested: request status becomes `rejected`, email unchanged | Rejected action does not execute |
| Approval acceptance | Not present | Tested: request status becomes `executed`, email changes | Explicit administrator approval executes the action |
| Audit evidence | Assignment 1 traces/security events | Separate `audit_log` records login, request, decision and result | Admin console exposes recent audit records |
| Average latency | 1.26 ms baseline in deterministic test run | Not yet measured as a comparable full-chat benchmark | Measure with same test set and hardware before claiming overhead |
| Input/output tokens | Unavailable (no LLM API used) | Unavailable in local security unit tests | Run live Groq evaluation to collect actual API usage |

## Assignment 2 scenario results

| Scenario | Expected result | Result |
|----------|----------------|--------|
| Correct student credentials | Login succeeds; role and student identity are established | PASS |
| Wrong password | Login denied; no session granted | PASS |
| Inactive account | Login denied | PASS |
| Password hash not plaintext | Hash stored, no plaintext in DB | PASS |
| Own-record fee/scholarship access | Tool returns own data | PASS |
| Cross-student record access denied | `not_authorized` error | PASS |
| Student cannot perform admin operations | `PermissionError` | PASS |
| Own email change request | Request becomes pending; current email unchanged | PASS |
| Admin rejects request | Status becomes `rejected`; email unchanged | PASS |
| Admin approves request | Status becomes `executed`; email changes | PASS |
| Repeated approval | Cannot execute twice | PASS |
| Invalid request state | Rejected | PASS |
| Student cannot approve own request | Denied; no mutation | PASS |
| Audit records login success/failure | `allowed`/`denied` entries | PASS |
| Audit records access-denied | `denied` entries in audit_log | PASS |
| Audit records sensitive action lifecycle | `request_change_email` + `review_approval` | PASS |
| Audit log contains no secrets | No plaintext passwords in audit_log | PASS |
| Password/OTP not persisted in memory | Nothing saved; no secret values in DB | PASS |
| API key/token not persisted in memory | Blocked by sensitivity filter | PASS |
| Non-sensitive preference persists | Language/style/contact/course stored | PASS |
| Sensitive value not in trace | `[REDACTED:...]` only | PASS |
| Admin creates student with login | New student can log in; fee row created | PASS |
| Admin resets password | Non-admin blocked; admin can reset; new password works | PASS |

## Evidence to show in demo video

1. Student signs in and sees only the identity associated with that account.
2. Student asks for own fee status successfully.
3. Student attempts another student's ID; tool authorization blocks the call.
4. Student requests an email change; show pending status and unchanged record.
5. Admin rejects one request; show status `rejected` and unchanged email.
6. Admin approves another request; show status `executed` and changed email.
7. Show audit records and traces. Explain that password hashes are salted PBKDF2 hashes and raw credentials are not placed in audit details.
8. Show sensitive-information filtering: password/OTP in chat is redacted and not stored.

## Evaluation commands

```powershell
# Run all unit tests
python -m pytest -q

# Run Assignment 1 evaluation (17 scenarios, demo mode)
DEMO_MODE=1 python -m evaluation.run_evaluation

# Initialize database with synthetic data
python -m database.init_db

# Run the application
streamlit run app.py
```

## Honest limitation

This is a local educational demonstration, not production authentication. Demo accounts and role passwords are shared defaults unless changed in `.env`. Use synthetic data only. A real deployment needs institutional SSO/MFA, secure session controls, rate limiting, account provisioning and security review.

