"""Reproducible evaluation. Run from the project root:  python -m evaluation.run_evaluation

* Uses a FRESH temporary SQLite database, so your demo database is never touched.
* Runs in whichever mode is configured: real Groq LLM when GROQ_API_KEY is set (and DEMO_MODE
  is not 1), otherwise the deterministic demo planner. The mode is written in every report.
* Pass/fail is decided by explicit expectations in test_cases.json; nothing is hand-edited.
"""
from __future__ import annotations

import json
import os
import statistics
import sys
import tempfile
import uuid
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))

_tmp = tempfile.mkdtemp(prefix="eval_db_")
os.environ["STUDENT_DB_PATH"] = str(Path(_tmp) / "eval.db")

from agent.orchestrator import StudentSupportAgent  # noqa: E402
from config import load_settings  # noqa: E402
from database.db import connect  # noqa: E402
from database.init_db import init_database  # noqa: E402
from retrieval.retriever import build_retriever  # noqa: E402


def _snapshot() -> dict:
    with connect() as c:
        return {"tickets": c.execute("SELECT COUNT(*) FROM support_requests").fetchone()[0]}


def check_step(resp, expect: dict) -> list[str]:
    """Return a list of failure reasons (empty list = pass)."""
    fails, tr, ans = [], resp.trace, resp.answer
    tools = [t["name"] for t in tr["tools"]]
    if "intent" in expect and tr["intent"] != expect["intent"]:
        fails.append(f"intent {tr['intent']} != {expect['intent']}")
    if "tools" in expect and sorted(tools) != sorted(expect["tools"]):
        fails.append(f"tools {tools} != {expect['tools']}")
    for s in expect.get("answer_contains", []):
        if s.lower() not in ans.lower():
            fails.append(f"answer missing '{s}'")
    if "answer_contains_any" in expect and not any(s.lower() in ans.lower() for s in expect["answer_contains_any"]):
        fails.append(f"answer contains none of {expect['answer_contains_any']}")
    for s in expect.get("answer_not_contains", []):
        if s.lower() in ans.lower():
            fails.append(f"answer leaked '{s}'")
    if "tool_error" in expect and expect["tool_error"] not in [t["error_code"] for t in tr["tools"]]:
        fails.append(f"expected tool error {expect['tool_error']}")
    for ref in expect.get("memory_refs", []):
        if ref not in tr["memory_refs"]:
            fails.append(f"memory ref {ref} not used")
    r = expect.get("retrieval")
    ids = [c["id"] for c in tr["retrieved_chunks"]]
    if r == "empty" and (not tr["retrieval_used"] or ids):
        fails.append("expected retrieval to return nothing")
    if r == "not_used" and tr["retrieval_used"]:
        fails.append("retrieval should not be used")
    if r and r.startswith("hit:") and not any(i.startswith(f"policy::{r[4:]}.") for i in ids):
        fails.append(f"no chunk from section {r[4:]} retrieved (got {ids})")
    return fails


def check_db(check: str, sid: str, before: dict) -> str | None:
    with connect() as c:
        if check == "ticket_created":
            now = c.execute("SELECT COUNT(*) FROM support_requests").fetchone()[0]
            return None if now == before["tickets"] + 1 else f"ticket count {before['tickets']} -> {now}"
        if check == "no_ticket_created":
            now = c.execute("SELECT COUNT(*) FROM support_requests").fetchone()[0]
            return None if now == before["tickets"] else "a ticket was created unexpectedly"
        if check.startswith("memory:"):
            key, val = check[7:].split("=", 1)
            row = c.execute("SELECT mem_value FROM student_memories WHERE student_id=? AND mem_key=?", (sid, key)).fetchone()
            return None if row and row[0] == val else f"memory {key} != {val}"
        if check == "memory_empty":
            n = c.execute("SELECT COUNT(*) FROM student_memories WHERE student_id=?", (sid,)).fetchone()[0]
            return None if n == 0 else f"{n} memories saved from sensitive message"
        if check == "security_event":
            n = c.execute("SELECT COUNT(*) FROM security_events").fetchone()[0]
            return None if n >= 1 else "no security event recorded"
        if check.startswith("no_secrets:"):
            secrets = check[11:].split("|")
            for table in ("traces", "student_memories", "security_events", "support_requests"):
                dump = json.dumps([tuple(r) for r in c.execute(f"SELECT * FROM {table}").fetchall()])
                for s in secrets:
                    if s in dump:
                        return f"secret found in table {table}"
            return None
    return f"unknown db check {check}"


def main() -> None:
    settings = load_settings()
    init_database()
    retriever = build_retriever(settings.embedding_backend)
    make_agent = lambda: StudentSupportAgent(settings, retriever)  # noqa: E731
    mode = make_agent().mode
    cases = json.loads((HERE / "test_cases.json").read_text(encoding="utf-8"))
    results, all_traces = [], []

    for case in cases:
        sid, before = case["student_id"], _snapshot()
        agent, session, history = make_agent(), uuid.uuid4().hex[:8], []
        step_out, fails = [], []
        for step in case["steps"]:
            if step.get("new_session"):  # brand-new agent object + empty history: only the DB persists
                agent, session, history = make_agent(), uuid.uuid4().hex[:8], []
            resp = agent.handle(step["message"], sid, session, history)
            history += [{"role": "user", "content": step["message"]}, {"role": "assistant", "content": resp.answer}]
            f = check_step(resp, step["expect"])
            fails += f
            all_traces.append(resp.trace)
            step_out.append({"question": step["message"], "answer": resp.answer, "intent": resp.trace["intent"],
                             "tools_used": [t["name"] for t in resp.trace["tools"]],
                             "tool_statuses": [t["status"] for t in resp.trace["tools"]],
                             "retrieved_evidence": resp.trace["retrieved_chunks"], "latency_ms": resp.trace["latency_ms"],
                             "input_tokens": resp.trace["input_tokens"], "output_tokens": resp.trace["output_tokens"],
                             "completed": resp.success, "step_failures": f,
                             "expected_retrieval": step["expect"].get("retrieval")})
        for chk in case.get("db_checks", []):
            if (msg := check_db(chk, sid, before)):
                fails.append(f"db check '{chk}': {msg}")
        results.append({"test_id": case["id"], "scenario": case["name"], "student_id_used": sid,
                        "passed": not fails, "completed": all(s["completed"] for s in step_out),
                        "failures": fails, "steps": step_out,
                        "notes": "; ".join(fails) if fails else "All expectations met."})

    # ----------------------------------------------------------- metrics
    lat = [s["latency_ms"] for r in results for s in r["steps"]]
    tool_calls = [(t) for tr in all_traces for t in tr["tools"]]
    api_in = [tr["input_tokens"] for tr in all_traces if tr["token_source"] == "api"]
    api_out = [tr["output_tokens"] for tr in all_traces if tr["token_source"] == "api"]
    ret_tests = [s for r in results for s in r["steps"] if s["expected_retrieval"] in ("empty",) or str(s["expected_retrieval"]).startswith("hit:")]
    ret_ok = [s for s in ret_tests if not s["step_failures"] or not any("retriev" in x or "chunk" in x for x in s["step_failures"])]
    n = len(results)
    metrics = {
        "evaluation_mode": "groq:" + settings.groq_model if mode == "groq" else "demo-deterministic (NO LLM)",
        "total_tests": n,
        "task_completion_rate": round(sum(r["completed"] for r in results) / n, 4),
        "task_accuracy": round(sum(r["passed"] for r in results) / n, 4),
        "tests_passed": sum(r["passed"] for r in results),
        "avg_latency_ms": round(statistics.mean(lat), 2), "median_latency_ms": round(statistics.median(lat), 2),
        "total_input_tokens_api_reported": sum(api_in) if api_in else "unavailable",
        "total_output_tokens_api_reported": sum(api_out) if api_out else "unavailable",
        "tool_calls": len(tool_calls),
        "tool_execution_success_rate": round(sum(t["status"] == "success" for t in tool_calls) / len(tool_calls), 4) if tool_calls else None,
        "tool_errors_expected_by_tests": sum(1 for c in cases for s in c["steps"] if "tool_error" in s["expect"]),
        "retrieval_checks": len(ret_tests),
        "retrieval_success_rate": round(len(ret_ok) / len(ret_tests), 4) if ret_tests else None,
        "definitions": {
            "task_completion_rate": "Share of tests where the agent finished every step without a system failure (a correct 'record not found' answer counts as completed).",
            "task_accuracy": "Share of tests where ALL explicit expectations passed (right tool, right data, right evidence, safe behaviour).",
            "tool_execution_success_rate": "Tool calls returning ok / all tool calls. Tests T12 and T13 deliberately trigger tool errors, so <100% is expected.",
            "retrieval_success_rate": "Over steps with a retrieval expectation: relevant section retrieved, or correct empty result for unanswerable questions.",
        },
        "honesty_note": ("Run in demo-deterministic mode: this validates tools, retrieval, memory, filtering, tracing and the agent loop, "
                         "NOT real LLM reasoning. Token counts are unavailable because no LLM API was called."
                         if mode == "demo" else
                         "Run against the real Groq API; token counts are API-reported. LLM output varies, so rerun to check stability."),
    }
    out = {"metrics": metrics, "results": results}
    (HERE / "evaluation_results.json").write_text(json.dumps(out, indent=2, ensure_ascii=False), encoding="utf-8")

    md = [f"# Evaluation Report", "", f"**Mode:** {metrics['evaluation_mode']}", "",
          f"> {metrics['honesty_note']}", "", "## Summary metrics", "", "| Metric | Value |", "|---|---|"]
    for k in ("total_tests", "tests_passed", "task_accuracy", "task_completion_rate", "avg_latency_ms", "median_latency_ms",
              "total_input_tokens_api_reported", "total_output_tokens_api_reported", "tool_calls",
              "tool_execution_success_rate", "tool_errors_expected_by_tests", "retrieval_success_rate"):
        md.append(f"| {k} | {metrics[k]} |")
    md += ["", "### Metric definitions", ""] + [f"- **{k}**: {v}" for k, v in metrics["definitions"].items()]
    md += ["", "## Per-test results", "",
           "| ID | Scenario | Result | Tools used | Evidence (chunk IDs) | Latency ms (sum) | In tok | Out tok | Notes |",
           "|---|---|---|---|---|---|---|---|---|"]
    for r in results:
        tools = ", ".join(t for s in r["steps"] for t in s["tools_used"]) or "-"
        ev = ", ".join(c["id"].split("::")[1] for s in r["steps"] for c in s["retrieved_evidence"]) or "-"
        lat_sum = round(sum(s["latency_ms"] for s in r["steps"]), 1)
        itok = "unavailable" if r["steps"][-1]["input_tokens"] is None else sum(s["input_tokens"] or 0 for s in r["steps"])
        otok = "unavailable" if r["steps"][-1]["output_tokens"] is None else sum(s["output_tokens"] or 0 for s in r["steps"])
        md.append(f"| {r['test_id']} | {r['scenario']} | {'✅ PASS' if r['passed'] else '❌ FAIL'} | {tools} | {ev} | {lat_sum} | {itok} | {otok} | {r['notes']} |")
    md += ["", "## Questions and answers", ""]
    for r in results:
        md.append(f"### {r['test_id']} - {r['scenario']}")
        for s in r["steps"]:
            answer = s["answer"].replace("\n", "\n> ")
            md += [f"**Q:** {s['question']}", "", f"> {answer}", ""]
    (HERE / "report.md").write_text("\n".join(md), encoding="utf-8")

    print(f"Mode: {metrics['evaluation_mode']}")
    print(f"Passed {metrics['tests_passed']}/{n}  accuracy={metrics['task_accuracy']}  completion={metrics['task_completion_rate']}")
    print(f"avg latency {metrics['avg_latency_ms']} ms, median {metrics['median_latency_ms']} ms; tool success {metrics['tool_execution_success_rate']}; retrieval {metrics['retrieval_success_rate']}")
    for r in results:
        print(("PASS " if r["passed"] else "FAIL "), r["test_id"], r["scenario"], "" if r["passed"] else r["failures"])
    sys.exit(0 if all(r["passed"] for r in results) else 1)


if __name__ == "__main__":
    main()
