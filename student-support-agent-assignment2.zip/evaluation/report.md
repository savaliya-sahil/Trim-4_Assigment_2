# Evaluation Report

**Mode:** demo-deterministic (NO LLM)

> Run in demo-deterministic mode: this validates tools, retrieval, memory, filtering, tracing and the agent loop, NOT real LLM reasoning. Token counts are unavailable because no LLM API was called.

## Summary metrics

| Metric | Value |
|---|---|
| total_tests | 17 |
| tests_passed | 17 |
| task_accuracy | 1.0 |
| task_completion_rate | 1.0 |
| avg_latency_ms | 1.26 |
| median_latency_ms | 1.2 |
| total_input_tokens_api_reported | unavailable |
| total_output_tokens_api_reported | unavailable |
| tool_calls | 8 |
| tool_execution_success_rate | 0.75 |
| tool_errors_expected_by_tests | 2 |
| retrieval_success_rate | 1.0 |

### Metric definitions

- **task_completion_rate**: Share of tests where the agent finished every step without a system failure (a correct 'record not found' answer counts as completed).
- **task_accuracy**: Share of tests where ALL explicit expectations passed (right tool, right data, right evidence, safe behaviour).
- **tool_execution_success_rate**: Tool calls returning ok / all tool calls. Tests T12 and T13 deliberately trigger tool errors, so <100% is expected.
- **retrieval_success_rate**: Over steps with a retrieval expectation: relevant section retrieved, or correct empty result for unanswerable questions.

## Per-test results

| ID | Scenario | Result | Tools used | Evidence (chunk IDs) | Latency ms (sum) | In tok | Out tok | Notes |
|---|---|---|---|---|---|---|---|---|
| T01 | Check own fee status | ✅ PASS | check_fee_status | - | 1.2 | unavailable | unavailable | All expectations met. |
| T02 | Check outstanding fee balance | ✅ PASS | check_fee_status | - | 1.0 | unavailable | unavailable | All expectations met. |
| T03 | Check scholarship application status | ✅ PASS | check_scholarship_status | - | 0.8 | unavailable | unavailable | All expectations met. |
| T04 | Fee policy question (late fee) | ✅ PASS | - | 2.2, 2.1 | 1.9 | unavailable | unavailable | All expectations met. |
| T05 | Scholarship policy question | ✅ PASS | - | 3.2, 3.3 | 2.0 | unavailable | unavailable | All expectations met. |
| T06 | Course change policy question | ✅ PASS | - | 5.1, 5.2, 5.3 | 2.0 | unavailable | unavailable | All expectations met. |
| T07 | Create a support request | ✅ PASS | create_support_request | - | 2.3 | unavailable | unavailable | All expectations met. |
| T08 | Remembered info within a session | ✅ PASS | - | - | 2.2 | unavailable | unavailable | All expectations met. |
| T09 | Persistent memory survives a NEW session (new agent instance) | ✅ PASS | - | - | 2.1 | unavailable | unavailable | All expectations met. |
| T10 | Password/OTP is not persisted | ✅ PASS | - | - | 1.8 | unavailable | unavailable | All expectations met. |
| T11 | Question not covered by the policy | ✅ PASS | - | - | 1.8 | unavailable | unavailable | All expectations met. |
| T12 | Missing student record | ✅ PASS | check_fee_status | - | 0.9 | unavailable | unavailable | All expectations met. |
| T13 | Invalid student ID format | ✅ PASS | check_scholarship_status | - | 0.5 | unavailable | unavailable | All expectations met. |
| T14 | Ticket request without details asks for them (no ticket created) | ✅ PASS | - | - | 0.3 | unavailable | unavailable | All expectations met. |
| T15 | Payment portal failure policy (demo scenario 2) | ✅ PASS | - | 6.1 | 1.7 | unavailable | unavailable | All expectations met. |
| T16 | Student with no scholarship application | ✅ PASS | check_scholarship_status | - | 0.7 | unavailable | unavailable | All expectations met. |
| T17 | Student profile lookup | ✅ PASS | get_student_record | - | 0.7 | unavailable | unavailable | All expectations met. |

## Questions and answers

### T01 - Check own fee status
**Q:** What is my current fee status?

> **Fee status for 2026-Autumn: Partially Paid**
> - Total fee: ₹120,000.00
> - Paid so far: ₹95,000.00
> - Outstanding balance: ₹25,000.00
> - Due date: 2026-11-15

### T02 - Check outstanding fee balance
**Q:** What is my outstanding balance?

> **Fee status for 2026-Autumn: Unpaid**
> - Total fee: ₹45,000.00
> - Paid so far: ₹0.00
> - Outstanding balance: ₹45,000.00
> - Due date: 2026-10-01
> 
> ⚠️ This payment is **overdue**. Late fees may apply - ask me about the late fee policy.

### T03 - Check scholarship application status
**Q:** What is the status of my scholarship application?

> **Merit Scholarship: Approved** (amount ₹15,000.00)
> - Applied on: 2026-08-20
> - Remarks: Approved for the 2026-27 academic year.

### T04 - Fee policy question (late fee)
**Q:** What is the late fee policy for overdue payments?

> Here is what the (fictional demo) handbook says:
> 
> **Section 2.2 - Refund policy**
> Refunds are available only for excess or duplicate payments and must be requested within 30 days of payment. Approved refunds are processed within 10 working days to the original payment method. Tuition fees are not refundable after the first two weeks of the term.
> 
> **Section 2.1 - Late fee policy**
> If fees remain unpaid after the due date, a late fee of 2% of the outstanding balance is charged for each week of delay, up to a maximum of 10%. A student may request a one-time late fee waiver per academic year by writing to the Accounts Office within 7 days of the due date.

### T05 - Scholarship policy question
**Q:** How do I apply for a scholarship and what documents are needed?

> Here is what the (fictional demo) handbook says:
> 
> **Section 3.2 - How to apply for a scholarship**
> Apply through the Scholarship section of the student portal during the application window, which runs from 1 August to 30 September. Required documents are the previous year's marksheet, an identity proof, a bank passbook copy, and an income certificate for need-based aid.
> 
> **Section 3.3 - Scholarship application statuses**
> An application can be Submitted, Under Review, Documents Required, Approved, or Rejected. The committee review takes about 15 working days. When the status is Documents Required, upload the missing documents within 7 days.

### T06 - Course change policy question
**Q:** What is the procedure to change my course?

> Here is what the (fictional demo) handbook says:
> 
> **Section 5.1 - Eligibility and deadline for a course change**
> A course change request must be submitted within the first 2 weeks of the semester. The student must have at least 75% attendance and no pending disciplinary action.
> 
> **Section 5.2 - Steps to change a course**
> First meet the academic advisor to discuss the change. Next submit the Course Change Form through the portal. The Head of Department must approve the request. Any fee difference between the old and new course is adjusted in the next fee instalment.

### T07 - Create a support request
**Q:** Please create a support ticket: my fee receipt for this term is not showing in the portal.

> ✅ Your support ticket has been created.
> - **Ticket ID: TKT-20261029-F320AB**
> - Category: fees
> - Status: Open
> - Created: 2026-10-29T09:18:50+00:00

### T08 - Remembered info within a session
**Q:** Please reply to me in Gujarati and keep answers short.

> Got it - I've saved your preferred language, preferred answer style. I'll remember it in future sessions.
> 
> _Note: your saved language preference is Gujarati, but demo mode can only reply in English._

**Q:** Which language did I ask you to use?

> Here is what I remember about you:
> - Preferred answer style: short
> - Preferred language: Gujarati

### T09 - Persistent memory survives a NEW session (new agent instance)
**Q:** I prefer replies in Hindi.

> Got it - I've saved your preferred language. I'll remember it in future sessions.
> 
> _Note: your saved language preference is Hindi, but demo mode can only reply in English._

**Q:** What preferences do you remember about me?

> Here is what I remember about you:
> - Preferred language: Hindi

### T10 - Password/OTP is not persisted
**Q:** My password is Hunter2! and my OTP is 482913. Please remember them.

> 🔒 For your safety I did **not** save or use the sensitive details in your message (passwords, OTPs, PINs and keys are never stored). Please never share them in chat.
> 
> How can I help you today? I can help with: **fee status**, **scholarship status**, your **student profile**, **support tickets**, and **handbook policies** (fees, scholarships, course changes, portal issues).

### T11 - Question not covered by the policy
**Q:** What is the hostel curfew time and mess menu?

> I couldn't find anything about that in the student handbook, so I can't give you a policy answer. I don't want to guess. You can ask me to create a support ticket so staff can help.

### T12 - Missing student record
**Q:** What is my fee status?

> I couldn't find a student record for that ID, so I can't share any details. Please check the student ID or contact the support office.

### T13 - Invalid student ID format
**Q:** What is my scholarship status?

> That student ID doesn't look valid (expected a format like STU1234), so I couldn't look anything up.

### T14 - Ticket request without details asks for them (no ticket created)
**Q:** Create a support ticket

> I can create a support ticket for you. Please describe the issue in a sentence or two (for example: *"Please create a support ticket: my fee receipt is missing"*).

### T15 - Payment portal failure policy (demo scenario 2)
**Q:** What is the policy if the payment portal fails?

> Here is what the (fictional demo) handbook says:
> 
> **Section 6.1 - Payment portal failure or downtime**
> If the payment portal fails or is unavailable, wait 30 minutes and try again, use a different browser or clear the browser cache, and check the portal status page. Do not pay repeatedly. If money was deducted but the payment does not show, keep the bank transaction reference and raise a support ticket in the "fees" category. The Accounts Office reconciles such payments within 3 working days. Late fees are waived for payments that were blocked by documented portal downtime.

### T16 - Student with no scholarship application
**Q:** What is my scholarship status?

> No scholarship application is on file for you. I can explain how to apply if you'd like.

### T17 - Student profile lookup
**Q:** What program am I enrolled in?

> **Aarav Mehta** (STU1001)
> - Program: B.Tech Computer Engineering
> - Semester: 3
> - Enrolled since: 2025
> - Status: Active
> - Email: aarav.mehta@example.edu
