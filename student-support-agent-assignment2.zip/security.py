"""Assignment 2 demo authentication, authorization, approval and audit helpers.

This is a teaching/demo implementation, not production SSO. Passwords are salted
PBKDF2 hashes; raw passwords are never written to SQLite or logs.
"""
from __future__ import annotations
import hashlib, hmac, json, os, secrets, uuid
from datetime import datetime, timezone
from database.db import connect

DEMO_STUDENT_PASSWORD = os.getenv('DEMO_STUDENT_PASSWORD', 'Student@123')
DEMO_ADMIN_PASSWORD = os.getenv('DEMO_ADMIN_PASSWORD', 'Admin@123')

def now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec='seconds')

def _hash(password: str, salt: bytes) -> str:
    return hashlib.pbkdf2_hmac('sha256', password.encode(), salt, 240_000).hex()

def ensure_demo_accounts() -> None:
    """Create demo accounts for synthetic students and one administrator, idempotently."""
    with connect() as conn:
        students = conn.execute('SELECT student_id FROM students').fetchall()
        for row in students:
            username = row['student_id'].lower()
            if not conn.execute('SELECT 1 FROM auth_users WHERE username=?', (username,)).fetchone():
                salt = secrets.token_bytes(16)
                conn.execute('INSERT INTO auth_users(username,role,student_id,password_salt,password_hash) VALUES(?,?,?,?,?)',
                    (username, 'student', row['student_id'], salt.hex(), _hash(DEMO_STUDENT_PASSWORD, salt)))
        if not conn.execute("SELECT 1 FROM auth_users WHERE username='admin'").fetchone():
            salt = secrets.token_bytes(16)
            conn.execute('INSERT INTO auth_users(username,role,student_id,password_salt,password_hash) VALUES(?,?,?,?,?)',
                ('admin','admin',None,salt.hex(),_hash(DEMO_ADMIN_PASSWORD,salt)))

def authenticate(username: str, password: str) -> dict | None:
    username = (username or '').strip().lower()
    with connect() as conn:
        row = conn.execute('SELECT username,role,student_id,password_salt,password_hash,active FROM auth_users WHERE username=?', (username,)).fetchone()
    if not row or not row['active']:
        audit(username or 'unknown', 'unknown', 'login', username, 'denied', 'invalid_credentials', {})
        return None
    actual = _hash(password or '', bytes.fromhex(row['password_salt']))
    if not hmac.compare_digest(actual, row['password_hash']):
        audit(row['username'], row['role'], 'login', row['student_id'], 'denied', 'invalid_credentials', {})
        return None
    user = {'username':row['username'], 'role':row['role'], 'student_id':row['student_id']}
    audit(user['username'], user['role'], 'login', user['student_id'], 'allowed', 'success', {})
    return user

def audit(actor: str, role: str, action: str, target: str | None, decision: str, result: str, details: dict) -> None:
    # Details must never include raw passwords, OTPs, or secrets.
    with connect() as conn:
        conn.execute('INSERT INTO audit_log(timestamp,actor,role,action,target,decision,result,details_json) VALUES(?,?,?,?,?,?,?,?)',
            (now(), actor, role, action, target, decision, result, json.dumps(details, ensure_ascii=False)[:4000]))

def request_email_change(user: dict, new_email: str) -> str:
    import re
    email = (new_email or '').strip()
    if not re.fullmatch(r"[^\s@]+@[^\s@]+\.[^\s@]+", email):
        raise ValueError('Please enter a valid email address.')
    if user.get('role') != 'student' or not user.get('student_id'):
        raise PermissionError('Only an authenticated student can request a change to their own email.')
    rid = 'APR-' + uuid.uuid4().hex[:10].upper()
    payload = {'new_email': email}
    with connect() as conn:
        conn.execute('INSERT INTO approval_requests(request_id,student_id,requested_by,action_type,payload_json,status,created_at) VALUES(?,?,?,?,?,?,?)',
            (rid, user['student_id'], user['username'], 'change_email', json.dumps(payload), 'pending', now()))
    audit(user['username'], user['role'], 'request_change_email', user['student_id'], 'approval_required', 'pending', {'request_id':rid})
    return rid

def list_approvals(status: str = 'pending') -> list[dict]:
    with connect() as conn:
        rows = conn.execute('''SELECT a.*, s.full_name FROM approval_requests a JOIN students s ON s.student_id=a.student_id
            WHERE a.status=? ORDER BY a.created_at''', (status,)).fetchall()
    return [dict(r) for r in rows]

def review_approval(admin: dict, request_id: str, approve: bool, note: str = '') -> tuple[bool,str]:
    if admin.get('role') != 'admin':
        audit(admin.get('username','unknown'), admin.get('role','unknown'), 'review_approval', request_id, 'denied', 'admin_required', {})
        return False, 'Administrator role required.'
    with connect() as conn:
        row = conn.execute('SELECT * FROM approval_requests WHERE request_id=?', (request_id,)).fetchone()
        if not row:
            return False, 'Approval request not found.'
        if row['status'] != 'pending':
            return False, f"Request is already {row['status']}; no action was executed."
        payload = json.loads(row['payload_json'])
        if not approve:
            conn.execute("UPDATE approval_requests SET status='rejected',reviewed_by=?,review_note=?,reviewed_at=? WHERE request_id=? AND status='pending'",
                (admin['username'], (note or 'Rejected by administrator')[:500], now(), request_id))
            rejected_student_id = row['student_id']
            rejected_action = row['action_type']
        elif row['action_type'] != 'change_email':
            return False, 'Unsupported approval action; nothing executed.'
        else:
            rejected_student_id = None
            rejected_action = None
        if not approve:
            pass
        else:
            # Re-check pending state and perform the mutation only on explicit admin approval.
            conn.execute('UPDATE students SET email=? WHERE student_id=?', (payload['new_email'], row['student_id']))
            conn.execute("UPDATE approval_requests SET status='executed',reviewed_by=?,review_note=?,reviewed_at=?,executed_at=? WHERE request_id=? AND status='pending'",
                (admin['username'], (note or 'Approved by administrator')[:500], now(), now(), request_id))
    if not approve:
        audit(admin['username'], 'admin', 'review_approval', rejected_student_id, 'rejected', 'not_executed', {'request_id':request_id,'action_type':rejected_action})
        return True, 'Rejected. The requested change was NOT executed.'
    audit(admin['username'], 'admin', 'review_approval', row['student_id'], 'approved', 'executed', {'request_id':request_id,'action_type':row['action_type']})
    return True, 'Approved and executed. Student email was updated.'

def recent_audit(limit: int = 100) -> list[dict]:
    with connect() as conn:
        rows = conn.execute('SELECT * FROM audit_log ORDER BY audit_id DESC LIMIT ?', (int(limit),)).fetchall()
    result=[]
    for r in rows:
        item=dict(r)
        try: item['details_json']=json.loads(item['details_json'])
        except Exception: pass
        result.append(item)
    return result


def create_student_account(admin: dict, full_name: str, email: str, program: str, semester: int, enrollment_year: int,
                           password: str = '', total_fee: float = 0, term: str = '', due_date: str = '') -> dict:
    """Admin only: add a student record, a login and an optional fee row. Returns the credentials so the admin can hand them over."""
    import re
    if admin.get('role') != 'admin':
        audit(admin.get('username', 'unknown'), admin.get('role', 'unknown'), 'create_student', None, 'denied', 'not_admin', {})
        raise PermissionError('Only an administrator can add students.')
    full_name, program, email = (full_name or '').strip(), (program or '').strip(), (email or '').strip()
    if not full_name or not program:
        raise ValueError('Full name and program are required.')
    if email and not re.fullmatch(r"[^\s@]+@[^\s@]+\.[^\s@]+", email):
        raise ValueError('Please enter a valid email address.')
    password = (password or '').strip() or secrets.token_urlsafe(9)
    if len(password) < 8:
        raise ValueError('Password must be at least 8 characters.')
    with connect() as conn:
        rows = conn.execute("SELECT student_id FROM students WHERE student_id GLOB 'STU[0-9]*'").fetchall()
        nums = [int(r['student_id'][3:]) for r in rows if r['student_id'][3:].isdigit()]
        student_id = f"STU{(max(nums) + 1) if nums else 1001}"
        conn.execute('INSERT INTO students(student_id,full_name,email,program,semester,enrollment_year) VALUES(?,?,?,?,?,?)',
                     (student_id, full_name, email or None, program, int(semester), int(enrollment_year)))
        if float(total_fee) > 0:
            conn.execute('INSERT INTO fees(student_id,term,total_fee,paid_amount,due_date) VALUES(?,?,?,?,?)',
                         (student_id, term.strip() or 'Current', float(total_fee), 0, due_date.strip() or None))
        salt = secrets.token_bytes(16)
        username = student_id.lower()
        conn.execute('INSERT INTO auth_users(username,role,student_id,password_salt,password_hash) VALUES(?,?,?,?,?)',
                     (username, 'student', student_id, salt.hex(), _hash(password, salt)))
    audit(admin['username'], 'admin', 'create_student', student_id, 'allowed', 'success', {})
    return {'student_id': student_id, 'username': username, 'password': password}


def reset_student_password(admin: dict, student_id: str, new_password: str = '') -> str:
    """Admin only: set a new password (generated if blank) and return it so the admin knows it."""
    if admin.get('role') != 'admin':
        raise PermissionError('Only an administrator can reset passwords.')
    new_password = (new_password or '').strip() or secrets.token_urlsafe(9)
    if len(new_password) < 8:
        raise ValueError('Password must be at least 8 characters.')
    salt = secrets.token_bytes(16)
    with connect() as conn:
        cur = conn.execute("UPDATE auth_users SET password_salt=?, password_hash=? WHERE student_id=? AND role='student'",
                           (salt.hex(), _hash(new_password, salt), student_id))
        if cur.rowcount == 0:
            raise ValueError('Student account not found.')
    audit(admin['username'], 'admin', 'reset_password', student_id, 'allowed', 'success', {})
    return new_password
