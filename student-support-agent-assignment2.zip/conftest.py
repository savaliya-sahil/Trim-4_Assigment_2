"""Pytest fixtures: every test gets a fresh, seeded temporary SQLite database."""
import os
import pytest


@pytest.fixture(autouse=True)
def temp_db(tmp_path, monkeypatch):
    monkeypatch.setenv("STUDENT_DB_PATH", str(tmp_path / "test.db"))
    monkeypatch.setenv("DEMO_MODE", "1")
    from database.init_db import init_database
    init_database()
    yield
