import json
from agent.orchestrator import StudentSupportAgent
from observability.metrics import summarize_traces
from observability.tracing import Trace, list_traces, save_trace
from database.db import connect

REQUIRED = {"trace_id", "timestamp", "student_ref", "question_redacted", "intent", "tools", "retrieval_used",
            "retrieved_chunks", "memory_refs", "success", "latency_ms", "model", "input_tokens", "output_tokens",
            "token_source", "errors"}


def test_trace_has_required_fields_and_redacts():
    t = Trace(student_ref="anon-x", question_redacted="my password is Hunter2")
    data = save_trace(t)
    assert REQUIRED <= set(data) and "Hunter2" not in json.dumps(data)
    assert list_traces(1)[0]["trace_id"] == t.trace_id


def test_demo_mode_reports_tokens_unavailable():
    agent = StudentSupportAgent(retriever=None)
    r = agent.handle("What is my current fee status?", "STU1001")
    assert r.trace["token_source"] == "unavailable" and r.trace["input_tokens"] is None
    assert r.trace["tools"][0]["name"] == "check_fee_status" and r.trace["latency_ms"] > 0
    assert "student_ref" in r.trace and "STU1001" not in json.dumps(r.trace)
    s = summarize_traces(list_traces())
    assert s["requests"] == 1 and s["total_input_tokens_api"] == "unavailable"


def test_secret_never_persisted_anywhere():
    agent = StudentSupportAgent(retriever=None)
    r = agent.handle("My password is Hunter2! and my OTP is 482913. Please remember them.", "STU1001")
    assert "Hunter2" not in r.answer
    with connect() as c:
        for table in ("traces", "student_memories", "security_events", "support_requests"):
            dump = json.dumps([tuple(row) for row in c.execute(f"SELECT * FROM {table}").fetchall()])
            assert "Hunter2" not in dump and "482913" not in dump, table
        assert c.execute("SELECT COUNT(*) FROM security_events").fetchone()[0] == 1
