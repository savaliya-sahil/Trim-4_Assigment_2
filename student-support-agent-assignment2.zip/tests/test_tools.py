from agent.tool_registry import ToolContext, execute_tool
from tools.student_tools import check_fee_status, check_scholarship_status, get_student_record
from tools.support_tools import create_support_request
from database.db import connect


def test_fee_status_calculates_balance():
    d = check_fee_status("STU1001")["data"]
    assert d["outstanding_balance"] == 25000 and d["payment_status"] == "Partially Paid"
    assert check_fee_status("stu1002")["data"]["payment_status"] == "Paid"
    assert check_fee_status("STU1003")["data"]["payment_status"] == "Unpaid"


def test_missing_and_invalid_ids():
    assert check_fee_status("STU9999")["error"]["code"] == "student_not_found"
    assert get_student_record("bad")["error"]["code"] == "invalid_student_id"
    assert check_scholarship_status(None)["error"]["code"] == "invalid_student_id"


def test_scholarship_none_and_present():
    assert check_scholarship_status("STU1003")["data"]["has_application"] is False
    assert check_scholarship_status("STU1002")["data"]["applications"][0]["status"] == "Approved"


def test_student_record():
    assert get_student_record("STU1001")["data"]["program"].startswith("B.Tech")


def test_create_ticket_persists_and_is_unique():
    a = create_support_request("STU1001", "fees", "My fee receipt is missing")
    b = create_support_request("STU1001", "fees", "My fee receipt is missing")
    assert a["ok"] and a["data"]["ticket_id"] != b["data"]["ticket_id"]
    with connect() as c:
        row = c.execute("SELECT status FROM support_requests WHERE ticket_id=?", (a["data"]["ticket_id"],)).fetchone()
    assert row["status"] == "Open"


def test_ticket_validation_and_secret_redaction():
    assert create_support_request("STU1001", "nope", "long enough text")["error"]["code"] == "invalid_category"
    assert create_support_request("STU1001", "fees", "short")["error"]["code"] == "description_too_short"
    t = create_support_request("STU1001", "technical", "Login fails, my password is Hunter2 please fix")
    assert "Hunter2" not in t["data"]["description"]


def test_registry_validation_and_authorization():
    ctx = ToolContext("STU1001")
    assert execute_tool("nope", {}, ctx).error_code == "unknown_tool"
    assert execute_tool("check_fee_status", "{bad json", ctx).error_code == "malformed_arguments"
    assert execute_tool("check_fee_status", {}, ctx).error_code == "invalid_arguments"
    assert execute_tool("check_fee_status", {"student_id": "STU1001", "x": 1}, ctx).error_code == "invalid_arguments"
    assert execute_tool("check_fee_status", {"student_id": "STU1002"}, ctx).error_code == "not_authorized"
    r = execute_tool("check_fee_status", '{"student_id": "STU1001"}', ctx)
    assert r.ok and r.duration_ms >= 0


def test_database_error_is_handled(monkeypatch, tmp_path):
    monkeypatch.setenv("STUDENT_DB_PATH", str(tmp_path))  # a directory -> sqlite cannot open it
    assert check_fee_status("STU1001")["error"]["code"] == "database_error"
