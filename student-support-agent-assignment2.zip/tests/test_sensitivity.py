import pytest
from memory.sensitivity_filter import scan_text


@pytest.mark.parametrize("text,cat", [
    ("My password is Hunter2!", "password"),
    ("my OTP is 482913", "otp"),
    ("482913 is my OTP", "otp"),
    ("here is my key gsk_abcdefghijklmnop1234", "api_key"),
    ("card 4111 1111 1111 1111", "card_number"),
    ("please remember my password", "secret_storage_request"),
])
def test_detects_secrets(text, cat):
    r = scan_text(text)
    assert r.is_sensitive and cat in r.categories
    assert "Hunter2" not in r.redacted_text and "482913" not in r.redacted_text


@pytest.mark.parametrize("text", ["What is my fee status?", "How do I reset my password on the portal?",
                                  "Ticket TKT-20260901-0001 for STU1001", "I prefer Hindi"])
def test_clean_text_not_flagged(text):
    assert not scan_text(text).is_sensitive
