from memory import memory_manager as mm
from database.db import connect


def test_save_dedupe_update_and_persist():
    assert mm.save_preferences("STU1001", "I prefer replies in Hindi").saved[0]["action"] == "created"
    assert mm.save_preferences("STU1001", "I prefer replies in Hindi").saved[0]["action"] == "unchanged"
    assert mm.save_preferences("STU1001", "Please reply in Gujarati").saved[0]["action"] == "updated"
    mems = mm.list_memories("STU1001")
    assert len(mems) == 1 and mems[0]["mem_value"] == "Gujarati"


def test_sensitive_message_saves_nothing():
    out = mm.save_preferences("STU1001", "I prefer Hindi. My password is Hunter2")
    assert out.blocked and mm.list_memories("STU1001") == []
    with connect() as c:
        assert c.execute("SELECT COUNT(*) FROM student_memories WHERE mem_value LIKE '%Hunter2%'").fetchone()[0] == 0


def test_relevance_gating_and_scoping():
    mm.save_preferences("STU1001", "I'm interested in machine learning")
    mm.save_preferences("STU1001", "Email me for updates")
    assert mm.get_relevant_memories("STU1001", "fee_status") == []
    keys = {m["mem_key"] for m in mm.get_relevant_memories("STU1001", "support_request")}
    assert keys == {"contact_preference"}
    assert len(mm.get_relevant_memories("STU1001", "memory_query")) == 2
    assert mm.get_relevant_memories("STU1002", "memory_query") == []


def test_clear_and_unknown_student():
    mm.save_preferences("STU1001", "Reply in Hindi")
    assert mm.clear_memories("STU1001") == 1
    assert mm.save_preferences("STU9999", "Reply in Hindi").saved == []
