import pytest
from retrieval.chunker import chunk_markdown
from retrieval.document_loader import DocumentLoadError, load_policy_text
from retrieval.retriever import Retriever, RetrievalError, build_retriever


@pytest.fixture(scope="module")
def retriever():
    return build_retriever("tfidf")


def test_chunking():
    chunks = chunk_markdown(load_policy_text())
    assert len(chunks) >= 15 and chunks[0].chunk_id.startswith("policy::")
    assert all(c.text for c in chunks)


@pytest.mark.parametrize("q,section", [
    ("What is the policy if the payment portal fails?", "6"),
    ("What is the late fee policy for overdue payments?", "2"),
    ("How do I apply for a scholarship and what documents are needed?", "3"),
    ("What is the procedure to change my course?", "5"),
])
def test_relevant_section_retrieved(retriever, q, section):
    res = retriever.search(q)
    assert not res.empty and res.hits[0][0].section_number == section
    assert len(res.hits) <= 3  # never the whole document


@pytest.mark.parametrize("q", ["What is the hostel curfew time and mess menu?", "Can I bring my pet to campus?", ""])
def test_unanswerable_returns_empty(retriever, q):
    assert retriever.search(q).empty


def test_errors_are_explicit(tmp_path):
    with pytest.raises(DocumentLoadError):
        load_policy_text(tmp_path / "missing.md")
    with pytest.raises(RetrievalError):
        Retriever([])


def test_fallback_reason_is_reported():
    r = build_retriever("sentence-transformers")  # not installed / no download in CI -> documented fallback
    assert r.backend in {"tfidf", "sentence-transformers"}
    if r.backend == "tfidf":
        assert r.fallback_reason
