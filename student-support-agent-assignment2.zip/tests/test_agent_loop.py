"""Agent-loop tests with a SCRIPTED fake LLM (no network). They verify the loop's control flow
(tool validation, bounds, error handling) - not real model reasoning."""
import json
import pytest
from agent.llm_client import LLMError, LLMResponse, ToolCall
from agent.orchestrator import StudentSupportAgent
from retrieval.retriever import build_retriever


class Scripted:
    def __init__(self, *responses):
        self.responses, self.calls = list(responses), 0

    def generate(self, messages, tool_specs, state):
        self.calls += 1
        r = self.responses[min(self.calls - 1, len(self.responses) - 1)]
        if isinstance(r, Exception):
            raise r
        return r


def call(name, args):
    return ToolCall("c1", name, args if isinstance(args, str) else json.dumps(args))


def run(llm, q="What is my current fee status?", sid="STU1001"):
    return StudentSupportAgent(llm=llm, retriever=build_retriever("tfidf")).handle(q, sid)


def test_tool_then_final_answer_records_api_tokens():
    llm = Scripted(LLMResponse(tool_calls=[call("check_fee_status", {"student_id": "STU1001"})], input_tokens=100, output_tokens=10),
                   LLMResponse(content="You owe 25,000.", input_tokens=150, output_tokens=8))
    r = run(llm)
    assert r.success and r.answer == "You owe 25,000."
    assert (r.trace["input_tokens"], r.trace["output_tokens"], r.trace["token_source"]) == (250, 18, "api")
    assert r.trace["tools"][0]["status"] == "success"


def test_malformed_tool_arguments_do_not_crash():
    llm = Scripted(LLMResponse(tool_calls=[call("check_fee_status", "{oops")]), LLMResponse(content="Sorry, could not check."))
    r = run(llm)
    assert r.success and r.trace["tools"][0]["error_code"] == "malformed_arguments"


def test_cross_student_tool_call_is_blocked():
    llm = Scripted(LLMResponse(tool_calls=[call("check_fee_status", {"student_id": "STU1002"})]), LLMResponse(content="Not allowed."))
    assert run(llm).trace["tools"][0]["error_code"] == "not_authorized"


def test_tool_not_offered_for_intent_is_rejected():
    llm = Scripted(LLMResponse(tool_calls=[call("create_support_request", {"student_id": "STU1001", "category": "fees", "description": "x" * 20})]),
                   LLMResponse(content="ok"))
    assert run(llm).trace["tools"][0]["error_code"] == "tool_not_allowed"


def test_infinite_tool_loop_is_bounded():
    llm = Scripted(LLMResponse(tool_calls=[call("check_fee_status", {"student_id": "STU1001"})]))
    r = run(llm)
    assert llm.calls == 4 and not r.success and "max_iterations_reached" in r.trace["errors"]


def test_empty_response_handled():
    r = run(Scripted(LLMResponse(content="  ")))
    assert not r.success and "llm_error:empty_response" in r.trace["errors"]


@pytest.mark.parametrize("kind", ["rate_limit", "network", "auth"])
def test_llm_failure_is_graceful_and_not_fabricated(kind):
    r = run(Scripted(LLMError(kind, "The AI service is unavailable.")))
    assert not r.success and r.trace["degraded"] and "unavailable" in r.answer and "Traceback" not in r.answer


def test_llm_failure_after_tool_shows_only_verified_data():
    llm = Scripted(LLMResponse(tool_calls=[call("check_fee_status", {"student_id": "STU1001"})]), LLMError("network", "Network problem."))
    r = run(llm)
    assert "25,000.00" in r.answer and not r.success


def test_model_answering_student_data_without_tool_gets_nudged():
    llm = Scripted(LLMResponse(content="You owe 1 rupee."),
                   LLMResponse(tool_calls=[call("check_fee_status", {"student_id": "STU1001"})]),
                   LLMResponse(content="You owe 25,000."))
    r = run(llm)
    assert "tool_required_nudge" in r.trace["flags"] and r.answer == "You owe 25,000."


def test_context_is_minimal_and_scoped():
    seen = {}

    class Spy(Scripted):
        def generate(self, messages, tool_specs, state):
            seen["text"] = json.dumps(messages)
            return LLMResponse(content="ok")
    r = run(Spy(), q="What is the policy if the payment portal fails?")
    assert "policy::6.1" in r.trace["context_report"]["policy_chunks"]
    assert "Aarav" not in seen["text"] and "STU1002" not in seen["text"]
    assert "Scholarship Application Procedure" not in seen["text"]  # whole handbook not sent
    assert r.trace["context_report"]["history_messages"] == 0


def test_retriever_missing_is_reported_honestly():
    r = StudentSupportAgent(retriever=None, retriever_error="boom").handle("What is the late fee policy?", "STU1001")
    assert "unavailable" in r.answer and "retrieval_unavailable" in r.trace["errors"]
