"""Assignment 2 authentication, authorization, approval workflow and audit tests."""
import json
from database.init_db import init_database
from database.db import connect
from security import (
    ensure_demo_accounts, authenticate, request_email_change, review_approval,
    create_student_account, reset_student_password, audit, list_approvals, recent_audit,
)
from agent.tool_registry import ToolContext, execute_tool
from tools.student_tools import check_fee_status, check_scholarship_status, get_student_record
from tools.support_tools import create_support_request
from memory.sensitivity_filter import scan_text
from observability.tracing import Trace, save_trace


def setup_demo(monkeypatch, tmp_path):
    monkeypatch.setenv('STUDENT_DB_PATH', str(tmp_path / 'a2.sqlite3'))
    init_database()
    ensure_demo_accounts()


def test_login_uses_password_hash_and_role(monkeypatch, tmp_path):
    setup_demo(monkeypatch, tmp_path)
    assert authenticate('stu1001', 'wrong-password') is None
    user = authenticate('stu1001', 'Student@123')
    admin = authenticate('admin', 'Admin@123')
    assert user['role'] == 'student' and user['student_id'] == 'STU1001'
    assert admin['role'] == 'admin' and admin['student_id'] is None
    with connect() as conn:
        row = conn.execute("SELECT password_hash FROM auth_users WHERE username='stu1001'").fetchone()
    assert 'Student@123' not in row['password_hash']


def test_rejected_sensitive_change_is_not_executed(monkeypatch, tmp_path):
    setup_demo(monkeypatch, tmp_path)
    user = authenticate('stu1001', 'Student@123')
    admin = authenticate('admin', 'Admin@123')
    request_id = request_email_change(user, 'new.email@example.edu')
    ok, message = review_approval(admin, request_id, False, 'Not approved')
    assert ok and 'NOT executed' in message
    with connect() as conn:
        email = conn.execute("SELECT email FROM students WHERE student_id='STU1001'").fetchone()['email']
        status = conn.execute('SELECT status FROM approval_requests WHERE request_id=?', (request_id,)).fetchone()['status']
    assert email == 'aarav.mehta@example.edu'
    assert status == 'rejected'


def test_approved_sensitive_change_executes_and_audits(monkeypatch, tmp_path):
    setup_demo(monkeypatch, tmp_path)
    user = authenticate('stu1001', 'Student@123')
    admin = authenticate('admin', 'Admin@123')
    request_id = request_email_change(user, 'new.email@example.edu')
    with connect() as conn:
        before = conn.execute("SELECT email FROM students WHERE student_id='STU1001'").fetchone()['email']
    assert before == 'aarav.mehta@example.edu'
    ok, _ = review_approval(admin, request_id, True, 'Verified')
    assert ok
    with connect() as conn:
        after = conn.execute("SELECT email FROM students WHERE student_id='STU1001'").fetchone()['email']
        status = conn.execute('SELECT status FROM approval_requests WHERE request_id=?', (request_id,)).fetchone()['status']
        audits = conn.execute('SELECT COUNT(*) AS n FROM audit_log WHERE action IN (\'request_change_email\',\'review_approval\')').fetchone()['n']
    assert after == 'new.email@example.edu' and status == 'executed' and audits >= 2


def test_non_admin_cannot_approve(monkeypatch, tmp_path):
    setup_demo(monkeypatch, tmp_path)
    user = authenticate('stu1001', 'Student@123')
    request_id = request_email_change(user, 'new.email@example.edu')
    ok, message = review_approval(user, request_id, True)
    assert not ok and 'Administrator' in message
    with connect() as conn:
        email = conn.execute("SELECT email FROM students WHERE student_id='STU1001'").fetchone()['email']
    assert email == 'aarav.mehta@example.edu'


# ------------------------------------------------------------------ authentication tests

def test_valid_login_and_identity(monkeypatch, tmp_path):
    setup_demo(monkeypatch, tmp_path)
    user = authenticate('stu1001', 'Student@123')
    assert user is not None
    assert user['username'] == 'stu1001'
    assert user['role'] == 'student'
    assert user['student_id'] == 'STU1001'


def test_invalid_login_denied(monkeypatch, tmp_path):
    setup_demo(monkeypatch, tmp_path)
    assert authenticate('stu1001', 'WrongPassword!') is None
    assert authenticate('unknown_student', 'anything') is None


def test_inactive_account_is_denied(monkeypatch, tmp_path):
    setup_demo(monkeypatch, tmp_path)
    with connect() as conn:
        conn.execute("UPDATE auth_users SET active=0 WHERE username='stu1001'")
    assert authenticate('stu1001', 'Student@123') is None


def test_logout_no_longer_allowed_without_session(monkeypatch, tmp_path):
    setup_demo(monkeypatch, tmp_path)
    user = authenticate('stu1001', 'Student@123')
    assert user is not None
    with connect() as conn:
        conn.execute("UPDATE auth_users SET active=0 WHERE username='stu1001'")
    assert authenticate('stu1001', 'Student@123') is None


def test_password_hash_is_not_plaintext(monkeypatch, tmp_path):
    setup_demo(monkeypatch, tmp_path)
    authenticate('stu1001', 'Student@123')
    with connect() as conn:
        row = conn.execute("SELECT password_hash FROM auth_users WHERE username='stu1001'").fetchone()
    assert row is not None
    assert 'Student@123' != row['password_hash']
    assert len(row['password_hash']) > 20


# ------------------------------------------------------------------ authorization tests

def _student_ctx(student_id: str) -> ToolContext:
    return ToolContext(student_id)


def test_tool_access_own_record(monkeypatch, tmp_path):
    setup_demo(monkeypatch, tmp_path)
    r = execute_tool('check_fee_status', {'student_id': 'STU1001'}, _student_ctx('STU1001'))
    assert r.ok and r.data['payment_status'] == 'Partially Paid'


def test_tool_denied_for_another_student_record(monkeypatch, tmp_path):
    setup_demo(monkeypatch, tmp_path)
    r = execute_tool('check_fee_status', {'student_id': 'STU1002'}, _student_ctx('STU1001'))
    assert not r.ok and r.error['code'] == 'not_authorized'


def test_tool_denied_for_student_attempting_admin_tool(monkeypatch, tmp_path):
    setup_demo(monkeypatch, tmp_path)
    user = authenticate('stu1001', 'Student@123')
    try:
        create_student_account(user, 'Evil Student', 'evil@example.edu', 'B.Com', 1, 2026)
        assert False, 'Expected PermissionError'
    except PermissionError:
        pass


def test_tool_calls_without_authentication_are_blocked(monkeypatch, tmp_path):
    setup_demo(monkeypatch, tmp_path)
    r = execute_tool('check_fee_status', {'student_id': 'STU1002'}, _student_ctx('STU1001'))
    assert not r.ok and r.error['code'] == 'not_authorized'


def test_student_cannot_perform_administrative_operations(monkeypatch, tmp_path):
    setup_demo(monkeypatch, tmp_path)
    student = authenticate('stu1001', 'Student@123')
    for action in (
        lambda: create_student_account(student, 'X', 'x@example.edu', 'B.Com', 1, 2026),
        lambda: reset_student_password(student, 'STU1002', 'NewPass123'),
    ):
        try:
            action()
            assert False, 'Expected PermissionError'
        except PermissionError:
            pass


# ------------------------------------------------------------------ approval workflow tests

def test_pending_request_does_not_execute(monkeypatch, tmp_path):
    setup_demo(monkeypatch, tmp_path)
    user = authenticate('stu1001', 'Student@123')
    request_id = request_email_change(user, 'changed@example.edu')
    with connect() as conn:
        row = conn.execute("SELECT status, reviewed_at, executed_at FROM approval_requests WHERE request_id=?", (request_id,)).fetchone()
        email = conn.execute("SELECT email FROM students WHERE student_id='STU1001'").fetchone()['email']
    assert row['status'] == 'pending'
    assert row['reviewed_at'] is None and row['executed_at'] is None
    assert email == 'aarav.mehta@example.edu'


def test_rejected_request_does_not_execute(monkeypatch, tmp_path):
    setup_demo(monkeypatch, tmp_path)
    user = authenticate('stu1001', 'Student@123')
    admin = authenticate('admin', 'Admin@123')
    request_id = request_email_change(user, 'changed@example.edu')
    ok, _ = review_approval(admin, request_id, False, 'Not approved')
    assert ok
    with connect() as conn:
        status = conn.execute("SELECT status FROM approval_requests WHERE request_id=?", (request_id,)).fetchone()['status']
        email = conn.execute("SELECT email FROM students WHERE student_id='STU1001'").fetchone()['email']
    assert status == 'rejected'
    assert email == 'aarav.mehta@example.edu'


def test_approved_request_executes_after_admin_check(monkeypatch, tmp_path):
    setup_demo(monkeypatch, tmp_path)
    user = authenticate('stu1001', 'Student@123')
    admin = authenticate('admin', 'Admin@123')
    request_id = request_email_change(user, 'changed@example.edu')
    ok, _ = review_approval(admin, request_id, True, 'Verified')
    assert ok
    with connect() as conn:
        status = conn.execute("SELECT status FROM approval_requests WHERE request_id=?", (request_id,)).fetchone()['status']
        email = conn.execute("SELECT email FROM students WHERE student_id='STU1001'").fetchone()['email']
    assert status == 'executed'
    assert email == 'changed@example.edu'


def test_repeated_approval_cannot_execute_twice(monkeypatch, tmp_path):
    setup_demo(monkeypatch, tmp_path)
    user = authenticate('stu1001', 'Student@123')
    admin = authenticate('admin', 'Admin@123')
    request_id = request_email_change(user, 'changed@example.edu')
    ok1, _ = review_approval(admin, request_id, True, 'First approval')
    assert ok1
    ok2, message = review_approval(admin, request_id, True, 'Second attempt')
    assert ok2 is False or 'already executed' in message.lower() or 'already' in message.lower()


def test_invalid_request_state_is_rejected(monkeypatch, tmp_path):
    setup_demo(monkeypatch, tmp_path)
    admin = authenticate('admin', 'Admin@123')
    ok, message = review_approval(admin, 'APR-NONEXISTENT', True)
    assert not ok
    ok2, message2 = review_approval(admin, 'APR-NONEXISTENT', False)
    assert not ok2


def test_student_cannot_change_own_approval_status(monkeypatch, tmp_path):
    setup_demo(monkeypatch, tmp_path)
    user = authenticate('stu1001', 'Student@123')
    request_id = request_email_change(user, 'changed@example.edu')
    ok, message = review_approval(user, request_id, True)
    assert not ok
    with connect() as conn:
        status = conn.execute("SELECT status FROM approval_requests WHERE request_id=?", (request_id,)).fetchone()['status']
        email = conn.execute("SELECT email FROM students WHERE student_id='STU1001'").fetchone()['email']
    assert status == 'pending'
    assert email == 'aarav.mehta@example.edu'


# ------------------------------------------------------------------ audit logging tests

def test_audit_records_login_success_and_failure(monkeypatch, tmp_path):
    setup_demo(monkeypatch, tmp_path)
    authenticate('stu1001', 'Student@123')
    authenticate('stu1001', 'wrong')
    with connect() as conn:
        rows = conn.execute("SELECT action, decision FROM audit_log WHERE action='login' ORDER BY audit_id DESC LIMIT 2").fetchall()
    assert [r['action'] for r in rows] == ['login', 'login']
    assert {r['decision'] for r in rows} == {'allowed', 'denied'}


def test_audit_records_access_denied(monkeypatch, tmp_path):
    setup_demo(monkeypatch, tmp_path)
    ctx = _student_ctx('STU1001')
    execute_tool('check_fee_status', {'student_id': 'STU1002'}, ctx)
    with connect() as conn:
        denied = conn.execute("SELECT COUNT(*) AS n FROM audit_log WHERE decision='denied'").fetchone()['n']
    assert denied >= 1


def test_audit_records_sensitive_action_lifecycle(monkeypatch, tmp_path):
    setup_demo(monkeypatch, tmp_path)
    user = authenticate('stu1001', 'Student@123')
    admin = authenticate('admin', 'Admin@123')
    request_id = request_email_change(user, 'changed@example.edu')
    review_approval(admin, request_id, True, 'Verified')
    with connect() as conn:
        actions = [r['action'] for r in conn.execute("SELECT action FROM audit_log ORDER BY audit_id").fetchall()]
    assert 'request_change_email' in actions
    assert 'review_approval' in actions


def test_audit_log_does_not_contain_secrets(monkeypatch, tmp_path):
    setup_demo(monkeypatch, tmp_path)
    authenticate('stu1001', 'Student@123')
    authenticate('admin', 'Admin@123')
    with connect() as conn:
        dump = json.dumps([tuple(r) for r in conn.execute("SELECT * FROM audit_log").fetchall()])
    assert 'Student@123' not in dump
    assert 'Admin@123' not in dump


# ------------------------------------------------------------------ memory and privacy tests

def test_password_and_otp_not_persisted_in_memory(monkeypatch, tmp_path):
    setup_demo(monkeypatch, tmp_path)
    from memory import memory_manager as mm
    out = mm.save_preferences('STU1001', 'My password is Hunter2 and OTP is 482913')
    assert out.blocked
    assert mm.list_memories('STU1001') == []
    with connect() as conn:
        assert conn.execute("SELECT COUNT(*) FROM student_memories WHERE mem_value LIKE '%Hunter2%'").fetchone()[0] == 0


def test_api_key_and_token_not_persisted_in_memory(monkeypatch, tmp_path):
    setup_demo(monkeypatch, tmp_path)
    from memory import memory_manager as mm
    out = mm.save_preferences('STU1001', 'my api key is sk-abc123def456ghi')
    assert out.blocked
    assert mm.list_memories('STU1001') == []


def test_non_sensitive_preference_persists(monkeypatch, tmp_path):
    setup_demo(monkeypatch, tmp_path)
    from memory import memory_manager as mm
    out = mm.save_preferences('STU1001', 'I prefer replies in Hindi')
    assert out.saved
    mems = mm.list_memories('STU1001')
    assert any(m['mem_key'] == 'preferred_language' and m['mem_value'] == 'Hindi' for m in mems)


def test_sensitive_value_not_in_trace(monkeypatch, tmp_path):
    setup_demo(monkeypatch, tmp_path)
    t = Trace(student_ref='anon-x', question_redacted='my password is Hunter2')
    data = save_trace(t)
    dump = json.dumps(data)
    assert 'Hunter2' not in dump


def test_student_created_has_login_and_fee_row(monkeypatch, tmp_path):
    setup_demo(monkeypatch, tmp_path)
    admin = authenticate('admin', 'Admin@123')
    created = create_student_account(admin, 'New Student', 'new@example.edu', 'BCA', 1, 2026, 'Str0ngP@ss', 50000, '2026-Autumn', '2026-12-31')
    assert created['student_id'].startswith('STU')
    assert authenticate(created['username'], created['password']) is not None
    with connect() as conn:
        fee = conn.execute("SELECT total_fee FROM fees WHERE student_id=?", (created['student_id'],)).fetchone()
        assert fee is not None and fee['total_fee'] == 50000


def test_password_reset_blocks_non_admin_and_changes_for_admin(monkeypatch, tmp_path):
    setup_demo(monkeypatch, tmp_path)
    student = authenticate('stu1001', 'Student@123')
    try:
        reset_student_password(student, 'STU1001', 'NewPass123')
        assert False, 'Expected PermissionError'
    except PermissionError:
        pass
    admin = authenticate('admin', 'Admin@123')
    new_pw = reset_student_password(admin, 'STU1001', 'NewPass123')
    assert authenticate('stu1001', 'NewPass123') is not None
